package com.skillsimprover.modules.service.impl;

import com.skillsimprover.modules.beans.UserBean;
import com.skillsimprover.modules.dao.UserDAO;
import com.skillsimprover.modules.entities.User;
import com.skillsimprover.modules.service.EntityBeanConverter;
import com.skillsimprover.modules.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDAO userDao;

    @Autowired
    private EntityBeanConverter converter;

    @Override
    public Iterable<UserBean> getAllUsers() {
        Iterable<User> users = userDao.findAll();
        List<UserBean> beanList = converter.convertToBeanList(users, UserBean.class);

        return beanList;
    }

    @Override
    public UserBean getUserById(Integer userId) {
        User user = userDao.findOne(userId);
        UserBean bean = converter.convertToBean(user, UserBean.class);

        return bean;
    }

    @Override
    public void saveUser(UserBean user) {
        User userEntity = converter.convertToEntity(user, User.class);
        userDao.save(userEntity);
    }

    @Override
    public void deleteUser(Integer userId) {
        userDao.delete(userId);
    }
}
