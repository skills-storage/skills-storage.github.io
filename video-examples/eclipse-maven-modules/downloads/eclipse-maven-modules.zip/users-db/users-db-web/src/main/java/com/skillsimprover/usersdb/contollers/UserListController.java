package com.skillsimprover.usersdb.contollers;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.skillsimprover.usersdb.dao.domain.User;
import com.skillsimprover.usersdb.service.UserService;
import com.skillsimprover.usersdb.service.impl.UserServiceImpl;

@WebServlet("/user-list.html")
public class UserListController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		String actionParam = request.getParameter("action");

		if ("save_user".equalsIgnoreCase(actionParam)) {
			doSaveUser(request);
		} else if ("update_user".equalsIgnoreCase(actionParam)) {
			doUpdateUser(request);
		} else if ("delete_user".equalsIgnoreCase(actionParam)) {
			doDeleteUser(request);
		}

		UserService userService = new UserServiceImpl();
		List<User> allUsers = userService.getAllUsers();
		HttpSession session = request.getSession();
		session.setAttribute("all_users_attr", allUsers);

		forwardToPoint("/WEB-INF/pages/userList.jsp", request, response);
	}

	private void doSaveUser(HttpServletRequest request) {
		// Implement SAVE logic here
	}

	private void doUpdateUser(HttpServletRequest request) {
		// Implement UPDATE logic here
	}

	private void doDeleteUser(HttpServletRequest request) {
		// Implement DELETE logic here
	}
}
