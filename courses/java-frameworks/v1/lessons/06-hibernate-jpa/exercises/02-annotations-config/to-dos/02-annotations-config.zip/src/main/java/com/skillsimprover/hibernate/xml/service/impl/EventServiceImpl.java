package com.skillsimprover.hibernate.xml.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skillsimprover.hibernate.xml.dao.EventDAO;
import com.skillsimprover.hibernate.xml.entities.Event;
import com.skillsimprover.hibernate.xml.service.EventService;

@Service
public class EventServiceImpl implements EventService {

	@Autowired
	private EventDAO eventDao;

	@Override
	public List<Event> getAllEvents() {
		return eventDao.loadAllEvents();
	}

	@Override
	public Event getEventById(Integer eventId) {
		return eventDao.loadEventById(eventId);
	}

	@Override
	public void saveEvent(Event event) {
		eventDao.storeEvent(event);
	}

	@Override
	public void deleteEvent(Integer eventId) {
		eventDao.deleteEvent(eventId);
	}
}
