package com.skillsimprover.hibernate.xml.dao;

import java.util.List;

import com.skillsimprover.hibernate.xml.entities.Event;

public interface EventDAO {

	List<Event> loadAllEvents();

	Event loadEventById(Integer eventId);

	Event storeEvent(Event event);

	void deleteEvent(Integer eventId);
}
