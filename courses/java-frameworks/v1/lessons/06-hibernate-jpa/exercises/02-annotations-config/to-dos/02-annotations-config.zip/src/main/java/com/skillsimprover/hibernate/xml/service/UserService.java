package com.skillsimprover.hibernate.xml.service;

import java.util.List;

import com.skillsimprover.hibernate.xml.entities.User;

public interface UserService {

	List<User> getAllUsers();

	User getUserById(Integer userId);

	void saveUser(User user);

	void deleteUser(Integer userId);
}
