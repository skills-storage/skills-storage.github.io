package com.skillsimprover.hibernate.xml.dao;

import java.util.List;

import com.skillsimprover.hibernate.xml.entities.User;

public interface UserDAO {

	List<User> loadAllUsers();

	User loadUserById(Integer userId);

	User storeUser(User user);

	void deleteUser(Integer userId);
}
