DROP SCHEMA IF EXISTS `events_db`;

CREATE SCHEMA IF NOT EXISTS `events_db`;

USE `events_db`;

-- ******************** Table Definitions ******************** 
CREATE TABLE `users` (
	`id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
	`user_name` VARCHAR(255) NOT NULL,
	`password` VARCHAR(255) NOT NULL
);

CREATE TABLE `events` (
	`id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
	`event_name` VARCHAR(255) NOT NULL,
	`event_desc` TEXT NOT NULL,
	`event_date` DATE NOT NULL,

	`fk_creator_id` INTEGER NOT NULL,

	CONSTRAINT `fk_creator` FOREIGN KEY (`fk_creator_id`) REFERENCES `users` (`id`)
		ON DELETE CASCADE
		ON UPDATE CASCADE
);

CREATE TABLE `users_to_events` (
	`fk_user_id` INTEGER NOT NULL,
	`fk_event_id` INTEGER NOT NULL,

	PRIMARY KEY(`fk_user_id`, `fk_event_id`),

	CONSTRAINT `user_to_event` FOREIGN KEY (`fk_user_id`) REFERENCES `users` (`id`)
		ON DELETE CASCADE
		ON UPDATE CASCADE,

	CONSTRAINT `event_to_user` FOREIGN KEY (`fk_event_id`) REFERENCES `events` (`id`)
		ON DELETE CASCADE
		ON UPDATE CASCADE
);


-- ************************ Test Data for table users ************************ 
INSERT INTO `users` (`id`, `user_name`, `password`) VALUES (1, 'ivan', 'ivan_123');
INSERT INTO `users` (`id`, `user_name`, `password`) VALUES (2, 'petr', 'petr_123');
INSERT INTO `users` (`id`, `user_name`, `password`) VALUES (3, 'sidor', 'sidor_123');

-- ************************ Test Data for table events ************************ 
INSERT INTO `events` (`id`, `event_name`, `event_desc`, `event_date`, `fk_creator_id`) VALUES (1, 'Java One', 'Very good conference for Java developers', '2017-01-17', 1);
INSERT INTO `events` (`id`, `event_name`, `event_desc`, `event_date`, `fk_creator_id`) VALUES (2, 'C++ conference', 'Very good conference for C\C++ developers', '2017-01-27', 1);
INSERT INTO `events` (`id`, `event_name`, `event_desc`, `event_date`, `fk_creator_id`) VALUES (3, 'PHP conference', 'Very good conference for PHP developers', '2017-01-30', 1);


-- ************************ Test Data for table users_to_events ************************ 
INSERT INTO `users_to_events` (`fk_user_id`, `fk_event_id`) VALUES(1, 1);
INSERT INTO `users_to_events` (`fk_user_id`, `fk_event_id`) VALUES(1, 2);
INSERT INTO `users_to_events` (`fk_user_id`, `fk_event_id`) VALUES(1, 3);

INSERT INTO `users_to_events` (`fk_user_id`, `fk_event_id`) VALUES(2, 1);
INSERT INTO `users_to_events` (`fk_user_id`, `fk_event_id`) VALUES(2, 2);
INSERT INTO `users_to_events` (`fk_user_id`, `fk_event_id`) VALUES(2, 3);

INSERT INTO `users_to_events` (`fk_user_id`, `fk_event_id`) VALUES(3, 1);
INSERT INTO `users_to_events` (`fk_user_id`, `fk_event_id`) VALUES(3, 2);
INSERT INTO `users_to_events` (`fk_user_id`, `fk_event_id`) VALUES(3, 3);
