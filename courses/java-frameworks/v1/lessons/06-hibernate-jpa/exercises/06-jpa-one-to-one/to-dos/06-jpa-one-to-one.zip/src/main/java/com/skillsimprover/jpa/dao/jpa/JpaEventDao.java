package com.skillsimprover.jpa.dao.jpa;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.skillsimprover.jpa.dao.EventDAO;
import com.skillsimprover.jpa.dao.jpa.utils.JpaUtils;
import com.skillsimprover.jpa.entities.Address;
import com.skillsimprover.jpa.entities.Event;

@Repository
public class JpaEventDao implements EventDAO {

	@Override
	public List<Event> loadAllEvents() {
		EntityManager manager = JpaUtils.getEntityManager();
		manager.getTransaction().begin();

		List<Event> result = manager.createQuery( "from Event", Event.class ).getResultList();

		manager.getTransaction().commit();

		return result;
	}

	@Override
	public Event loadEventById(Integer eventId) {
		EntityManager manager = JpaUtils.getEntityManager();
		manager.getTransaction().begin();

		Event event = manager.find(Event.class, eventId);

		manager.getTransaction().commit();

		return event;
	}

	@Override
	public Event storeEvent(Event event) {
		EntityManager manager = JpaUtils.getEntityManager();
		manager.getTransaction().begin();

		Address address = event.getAddress();
		address = manager.merge(address);

		event.setAddress(address);
		event.setId(address.getId());

		manager.merge(event);

		manager.getTransaction().commit();

		return event;
	}

	@Override
	public void deleteEvent(Integer eventId) {
		EntityManager manager = JpaUtils.getEntityManager();
		manager.getTransaction().begin();

		Event event = manager.find(Event.class, eventId);
		manager.remove(event);

		manager.getTransaction().commit();
	}
}
