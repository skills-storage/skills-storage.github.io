package com.skillsimprover.jpa.beans;

import java.util.ArrayList;
import java.util.List;

public class UserBean {

	private Integer id;

	private String userName;

	private String password;

	private Integer eventCount;

	private List<VisitEventBean> goingToVisit;

	public UserBean() {
		this.goingToVisit = new ArrayList<>();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getEventCount() {
		return eventCount;
	}

	public void setEventCount(Integer eventCount) {
		this.eventCount = eventCount;
	}

	public List<VisitEventBean> getGoingToVisit() {
		return goingToVisit;
	}

	public void setGoingToVisit(List<VisitEventBean> goingToVisit) {
		this.goingToVisit = goingToVisit;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		if (getClass() != obj.getClass()) {
			return false;
		}

		UserBean other = (UserBean) obj;
		if (userName == null) {
			if (other.userName != null) {
				return false;
			}
		} else if (!userName.equals(other.userName)) {
			return false;
		}

		return true;
	}

	@Override
	public String toString() {
		return "UserBean [id=" + id + ", userName=" + userName + ", password=" + password + ", eventCount=" + eventCount
				+ "]";
	}
}
