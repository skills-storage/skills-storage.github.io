package com.skillsimprover.jpa.dao.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.skillsimprover.jpa.dao.UserDAO;
import com.skillsimprover.jpa.dao.jpa.utils.JpaUtils;
import com.skillsimprover.jpa.entities.User;

@Repository
public class JpaUserDao implements UserDAO {

	@Override
	public List<User> loadAllUsers() {
		EntityManager manager = JpaUtils.getEntityManager();
		manager.getTransaction().begin();

		List<User> result = manager.createQuery( "from User", User.class ).getResultList();

		manager.getTransaction().commit();

		return result;
	}

	@Override
	public User loadUserById(Integer userId) {
		EntityManager manager = JpaUtils.getEntityManager();
		manager.getTransaction().begin();

		User user = manager.find(User.class, userId);

		manager.getTransaction().commit();

		return user;
	}

	@Override
	public User loadUserByUsername(String userName) {
		EntityManager manager = JpaUtils.getEntityManager();
		manager.getTransaction().begin();

		Query query = manager.createNamedQuery("User.findByUserName");
		query.setParameter("userName", userName);
		User user = (User) query.getSingleResult();

		manager.getTransaction().commit();

		return user;
	}

	@Override
	public User storeUser(User user) {
		EntityManager manager = JpaUtils.getEntityManager();
		manager.getTransaction().begin();

		manager.merge(user);

		manager.getTransaction().commit();

		return user;
	}

	@Override
	public void deleteUser(Integer userId) {
		EntityManager manager = JpaUtils.getEntityManager();
		manager.getTransaction().begin();

		User user = manager.find(User.class, userId);
		manager.remove(user);

		manager.getTransaction().commit();
	}
}
