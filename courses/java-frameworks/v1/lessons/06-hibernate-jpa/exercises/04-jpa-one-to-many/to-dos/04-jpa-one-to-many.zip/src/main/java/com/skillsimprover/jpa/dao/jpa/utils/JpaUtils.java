package com.skillsimprover.jpa.dao.jpa.utils;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public final class JpaUtils {

	private static final EntityManagerFactory entityManagerFactory = buildEntityManagerFactory();

    private JpaUtils() {
		throw new InstantiationError("No need to create an instance of this class!");
	}

	private static EntityManagerFactory buildEntityManagerFactory() {
		return Persistence.createEntityManagerFactory( "events_db" );
    }

    public static EntityManager getEntityManager() {
    	return entityManagerFactory.createEntityManager();
    }
}
