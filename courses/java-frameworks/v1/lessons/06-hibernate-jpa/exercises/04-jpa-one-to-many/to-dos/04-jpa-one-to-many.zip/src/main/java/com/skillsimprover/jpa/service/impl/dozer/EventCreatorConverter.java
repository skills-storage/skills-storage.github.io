package com.skillsimprover.jpa.service.impl.dozer;

import org.dozer.DozerConverter;
import org.springframework.beans.factory.annotation.Autowired;

import com.skillsimprover.jpa.dao.UserDAO;
import com.skillsimprover.jpa.entities.User;

public class EventCreatorConverter extends DozerConverter<User, String> {

	@Autowired
	private UserDAO userDao;

	public EventCreatorConverter() {
		super(User.class, String.class);
	}

	@Override
	public String convertTo(User source, String destination) {
		return source.getUserName();
	}

	@Override
	public User convertFrom(String source, User destination) {
		User user = userDao.loadUserByUsername(source);
		return user;
	}

}
