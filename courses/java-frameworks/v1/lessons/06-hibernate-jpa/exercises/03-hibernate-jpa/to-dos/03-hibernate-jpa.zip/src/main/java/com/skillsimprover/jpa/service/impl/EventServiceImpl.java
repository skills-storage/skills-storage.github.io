package com.skillsimprover.jpa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skillsimprover.jpa.dao.EventDAO;
import com.skillsimprover.jpa.entities.Event;
import com.skillsimprover.jpa.service.EventService;

@Service
public class EventServiceImpl implements EventService {

	@Autowired
	private EventDAO eventDao;

	public List<Event> getAllEvents() {
		return eventDao.loadAllEvents();
	}

	public Event getEventById(Integer eventId) {
		return eventDao.loadEventById(eventId);
	}

	public void saveEvent(Event event) {
		eventDao.storeEvent(event);
	}

	public void deleteEvent(Integer eventId) {
		eventDao.deleteEvent(eventId);
	}
}
