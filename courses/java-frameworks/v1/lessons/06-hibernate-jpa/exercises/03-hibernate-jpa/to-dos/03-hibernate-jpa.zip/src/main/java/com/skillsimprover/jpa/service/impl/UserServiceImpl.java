package com.skillsimprover.jpa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skillsimprover.jpa.dao.UserDAO;
import com.skillsimprover.jpa.entities.User;
import com.skillsimprover.jpa.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDao;

	public List<User> getAllUsers() {
		return userDao.loadAllUsers();
	}

	public User getUserById(Integer userId) {
		return userDao.loadUserById(userId);
	}

	public void saveUser(User user) {
		userDao.storeUser(user);
	}

	public void deleteUser(Integer userId) {
		userDao.deleteUser(userId);
	}
}
