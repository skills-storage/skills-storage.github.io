package com.skillsimprover.jpa.dao.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.skillsimprover.jpa.dao.UserDAO;
import com.skillsimprover.jpa.dao.jpa.utils.JpaUtils;
import com.skillsimprover.jpa.entities.User;

@Repository
public class JpaUserDao implements UserDAO {

	public List<User> loadAllUsers() {
		EntityManager manager = JpaUtils.getEntityManager();
		TypedQuery<User> query = manager.createQuery( "from User", User.class );
		List<User> result = query.getResultList();

		return result;
	}

	public User loadUserById(Integer userId) {
		EntityManager manager = JpaUtils.getEntityManager();
		return manager.find(User.class, userId);
	}

	public User storeUser(User user) {
		EntityManager manager = JpaUtils.getEntityManager();
		manager.getTransaction().begin();

		manager.merge(user);

		manager.getTransaction().commit();
		return user;
	}

	public void deleteUser(Integer userId) {
		EntityManager manager = JpaUtils.getEntityManager();
		manager.getTransaction().begin();

		User user = manager.find(User.class, userId);
		manager.remove(user);

		manager.getTransaction().commit();
	}
}
