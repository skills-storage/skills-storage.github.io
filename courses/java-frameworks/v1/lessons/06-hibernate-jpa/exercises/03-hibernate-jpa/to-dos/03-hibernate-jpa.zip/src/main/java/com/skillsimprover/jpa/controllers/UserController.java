package com.skillsimprover.jpa.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.skillsimprover.jpa.entities.User;
import com.skillsimprover.jpa.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	@RequestMapping("/users.html")
	public ModelAndView showUsersPage() {
		ModelAndView modelAndView = new ModelAndView("users");
		return modelAndView;
	}

	@RequestMapping("/update-user.html")
	public ModelAndView updateUser(@RequestParam(name = "user_id") Integer userId) {
		ModelAndView modelAndView = new ModelAndView("users");

		User user = userService.getUserById(userId);
		modelAndView.addObject("user", user);

		return modelAndView;
	}

	@RequestMapping("/delete-user.html")
	public ModelAndView deleteUser(@RequestParam(name = "user_id") Integer userId) {
		userService.deleteUser(userId);

		ModelAndView modelAndView = new ModelAndView("redirect:users.html");
		return modelAndView;
	}

	@RequestMapping(value = "/save-user.html", method = RequestMethod.POST)
	public ModelAndView saveUser(User user) {
		userService.saveUser(user);

		ModelAndView modelAndView = new ModelAndView("redirect:users.html");
		return modelAndView;
	}

	@ModelAttribute(name = "userList")
	private List<User> getUserList() {
		List<User> userList = userService.getAllUsers();
		return userList;
	}

	@ModelAttribute(name = "user")
	private User getEmptyUser() {
		return new User();
	}
}
