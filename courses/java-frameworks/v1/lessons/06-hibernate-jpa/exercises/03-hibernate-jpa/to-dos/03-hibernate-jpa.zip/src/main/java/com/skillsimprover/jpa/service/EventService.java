package com.skillsimprover.jpa.service;

import java.util.List;

import com.skillsimprover.jpa.entities.Event;

public interface EventService {

	List<Event> getAllEvents();

	Event getEventById(Integer eventId);

	void saveEvent(Event event);

	void deleteEvent(Integer eventId);
}
