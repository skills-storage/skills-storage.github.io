package com.skillsimprover.jpa.service;

import java.util.List;

import com.skillsimprover.jpa.entities.User;

public interface UserService {

	List<User> getAllUsers();

	User getUserById(Integer userId);

	void saveUser(User user);

	void deleteUser(Integer userId);
}
