package com.skillsimprover.jpa.dao.jpa;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.skillsimprover.jpa.dao.EventDAO;
import com.skillsimprover.jpa.dao.jpa.utils.JpaUtils;
import com.skillsimprover.jpa.entities.Event;

@Repository
public class JpaEventDao implements EventDAO {

	public List<Event> loadAllEvents() {
		EntityManager manager = JpaUtils.getEntityManager();
		List<Event> result = manager.createQuery( "from Event", Event.class ).getResultList();

		return result;
	}

	public Event loadEventById(Integer eventId) {
		EntityManager manager = JpaUtils.getEntityManager();
		return manager.find(Event.class, eventId);
	}

	public Event storeEvent(Event event) {
		EntityManager manager = JpaUtils.getEntityManager();
		manager.getTransaction().begin();

		manager.merge(event);

		manager.getTransaction().commit();

		return event;
	}

	public void deleteEvent(Integer eventId) {
		EntityManager manager = JpaUtils.getEntityManager();
		manager.getTransaction().begin();

		Event event = manager.find(Event.class, eventId);
		manager.remove(event);

		manager.getTransaction().commit();
	}
}
