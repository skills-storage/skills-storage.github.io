package com.skillsimprover.hibernate.xml.dao.hibernate;

import java.util.List;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.skillsimprover.hibernate.xml.dao.EventDAO;
import com.skillsimprover.hibernate.xml.dao.hibernate.utils.HibernateUtils;
import com.skillsimprover.hibernate.xml.entities.Event;

@Repository
public class HibernateEventDao implements EventDAO {

	@Override
	public List<Event> loadAllEvents() {
		Session session = HibernateUtils.getCurrentSession();
		session.beginTransaction();

		List<Event> result = session.getNamedQuery("load_all_events").list();
		session.getTransaction().commit();

		return result;
	}

	@Override
	public Event loadEventById(Integer eventId) {
		Session session = HibernateUtils.getCurrentSession();
		session.beginTransaction();

		Event result = session.find(Event.class, eventId);
		session.getTransaction().commit();

		return result;
	}

	@Override
	public Event storeEvent(Event event) {
		Session session = HibernateUtils.getCurrentSession();
		session.beginTransaction();

		session.saveOrUpdate(event);
		session.getTransaction().commit();

		return event;
	}

	@Override
	public void deleteEvent(Integer eventId) {
		Event event = loadEventById(eventId);

		Session session = HibernateUtils.getCurrentSession();
		session.beginTransaction();

		session.delete(event);
		session.getTransaction().commit();
	}
}
