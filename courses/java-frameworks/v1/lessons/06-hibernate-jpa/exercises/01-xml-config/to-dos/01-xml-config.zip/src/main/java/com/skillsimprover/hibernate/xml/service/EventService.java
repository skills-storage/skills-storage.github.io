package com.skillsimprover.hibernate.xml.service;

import java.util.List;

import com.skillsimprover.hibernate.xml.entities.Event;

public interface EventService {

	List<Event> getAllEvents();

	Event getEventById(Integer eventId);

	void saveEvent(Event event);

	void deleteEvent(Integer eventId);
}
