package com.skillsimprover.hibernate.xml.dao.hibernate.utils;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public final class HibernateUtils {

	private static final SessionFactory sessionFactory = buildSessionFactory();

    private HibernateUtils() {
		throw new InstantiationError("No need to create an instance of this class!");
	}

	private static SessionFactory buildSessionFactory() {
		// A SessionFactory is set up once for an application!
		final StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure().build();
		try {
			return new MetadataSources( registry ).buildMetadata().buildSessionFactory();
		}
		catch (Exception e) {
			StandardServiceRegistryBuilder.destroy( registry );

			throw new ExceptionInInitializerError(e);
		}
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static Session getCurrentSession() {
    	return getSessionFactory().getCurrentSession();
    }
}
