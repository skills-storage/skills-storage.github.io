package com.skillsimprover.hibernate.xml.dao.hibernate;

import java.util.List;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.skillsimprover.hibernate.xml.dao.UserDAO;
import com.skillsimprover.hibernate.xml.dao.hibernate.utils.HibernateUtils;
import com.skillsimprover.hibernate.xml.entities.User;

@Repository
public class HibernateUserDao implements UserDAO {

	@Override
	public List<User> loadAllUsers() {
		Session session = HibernateUtils.getCurrentSession();
		session.beginTransaction();

		List<User> result = session.getNamedQuery("load_all_users").list();
		session.getTransaction().commit();

		return result;
	}

	@Override
	public User loadUserById(Integer userId) {
		Session session = HibernateUtils.getCurrentSession();
		session.beginTransaction();

		User user = session.find(User.class, userId);

		session.getTransaction().commit();

		return user;
	}

	@Override
	public User storeUser(User user) {
		Session session = HibernateUtils.getCurrentSession();
		session.beginTransaction();

		session.saveOrUpdate(user);

		session.getTransaction().commit();

		return user;
	}

	@Override
	public void deleteUser(Integer userId) {
		User user = loadUserById(userId);

		Session session = HibernateUtils.getCurrentSession();
		session.beginTransaction();

		session.delete(user);

		session.getTransaction().commit();
	}
}
