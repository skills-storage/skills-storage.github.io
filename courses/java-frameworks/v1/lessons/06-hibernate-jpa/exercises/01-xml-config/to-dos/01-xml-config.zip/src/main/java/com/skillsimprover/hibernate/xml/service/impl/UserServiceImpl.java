package com.skillsimprover.hibernate.xml.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skillsimprover.hibernate.xml.dao.UserDAO;
import com.skillsimprover.hibernate.xml.entities.User;
import com.skillsimprover.hibernate.xml.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDao;

	@Override
	public List<User> getAllUsers() {
		return userDao.loadAllUsers();
	}

	@Override
	public User getUserById(Integer userId) {
		return userDao.loadUserById(userId);
	}

	@Override
	public void saveUser(User user) {
		userDao.storeUser(user);
	}

	@Override
	public void deleteUser(Integer userId) {
		userDao.deleteUser(userId);
	}
}
