package com.skillsimprover.spring.security.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.skillsimprover.spring.security.entities.Role;

@Repository
public interface RoleDAO extends CrudRepository<Role, Integer> {

	@Query("SELECT r FROM Role r WHERE LOWER(r.name) = LOWER(:roleName)")
	Role loadRoleByName(@Param("roleName") String roleName);
}
