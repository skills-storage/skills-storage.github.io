package com.skillsimprover.spring.security.service.impl.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

import com.skillsimprover.spring.security.beans.RoleBean;
import com.skillsimprover.spring.security.beans.UserBean;
import com.skillsimprover.spring.security.beans.security.GrantedAuthorityBean;
import com.skillsimprover.spring.security.beans.security.LoggedAccountBean;
import com.skillsimprover.spring.security.service.UserService;

public class CustomAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	private UserService userService;

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		LoggedAccountBean loggedAccount = createLoggedAccount(authentication);
		String password = (String) authentication.getCredentials();

		if (!password.equals(loggedAccount.getPassword())) {
			throw new BadCredentialsException("Wrong password.<br> Неправильный пароль");
		}

		if (!loggedAccount.isAccountNonLocked()) {
			throw new LockedException("User Account is locked!<br>Аккаунт заблокирован!", new Exception());
		}

		return new UsernamePasswordAuthenticationToken(loggedAccount, password, loggedAccount.getAuthorities());
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return true;
	}

	private LoggedAccountBean createLoggedAccount(Authentication authentication) {
		String userName = authentication.getName();

		UserBean user = userService.getUserByUserName(userName);
		List<RoleBean> roles = user.getRoles();

		Collection<GrantedAuthorityBean> authorities = getUserAuthorities(roles);

		LoggedAccountBean loggedAccount = new LoggedAccountBean(user, authorities);

		return loggedAccount;
	}

	private Collection<GrantedAuthorityBean> getUserAuthorities(List<RoleBean> roles) {
		Collection<GrantedAuthorityBean> authorities = new ArrayList<>();

		for (RoleBean role : roles) {
			GrantedAuthorityBean bean = new GrantedAuthorityBean(role.getName());
			authorities.add(bean);
		}

		return authorities;
	}
}
