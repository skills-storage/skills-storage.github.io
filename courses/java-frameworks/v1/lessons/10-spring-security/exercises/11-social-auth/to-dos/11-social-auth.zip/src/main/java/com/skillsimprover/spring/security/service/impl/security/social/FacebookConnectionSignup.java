package com.skillsimprover.spring.security.service.impl.security.social;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.social.connect.Connection;
import org.springframework.social.connect.ConnectionSignUp;
import org.springframework.stereotype.Service;

import com.skillsimprover.spring.security.dao.RoleDAO;
import com.skillsimprover.spring.security.dao.UserDAO;
import com.skillsimprover.spring.security.entities.Role;
import com.skillsimprover.spring.security.entities.User;

@Service
public class FacebookConnectionSignup implements ConnectionSignUp {

	@Autowired
	private RoleDAO roleDao;

	@Autowired
	private UserDAO userDao;

	@Override
	public String execute(Connection<?> connection) {
		Role reguserRole = roleDao.loadRoleByName("regular_user");

		User user = new User();
		user.setUserName(connection.getDisplayName());
		user.setPassword("1234");
		user.setEnabled(true);
		user.setRoles(Arrays.asList(reguserRole));

		userDao.save(user);

		return user.getUserName();
	}
}
