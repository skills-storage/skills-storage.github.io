package com.skillsimprover.spring.security.service;

import com.skillsimprover.spring.security.beans.UserBean;

public interface UserService {

	Iterable<UserBean> getAllUsers();

	UserBean getUserById(Integer userId);

	UserBean getUserByUserName(String userName);

	void saveUser(UserBean user);

	void deleteUser(Integer userId);
}
