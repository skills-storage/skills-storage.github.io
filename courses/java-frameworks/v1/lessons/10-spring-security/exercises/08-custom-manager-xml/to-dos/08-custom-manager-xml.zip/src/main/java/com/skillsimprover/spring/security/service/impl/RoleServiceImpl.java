package com.skillsimprover.spring.security.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.spring.security.beans.RoleBean;
import com.skillsimprover.spring.security.dao.RoleDAO;
import com.skillsimprover.spring.security.entities.Role;
import com.skillsimprover.spring.security.service.EntityBeanConverter;
import com.skillsimprover.spring.security.service.RoleService;

@Service
@Transactional
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleDAO roleDao;

	@Autowired
	private EntityBeanConverter converter;

	@Override
	public Iterable<RoleBean> getAllRoles() {
		Iterable<Role> roles = roleDao.findAll();
		List<RoleBean> beanList = converter.convertToBeanList(roles, RoleBean.class);

		return beanList;
	}

	@Override
	public RoleBean getRoleById(Integer roleId) {
		Role role = roleDao.findOne(roleId);
		RoleBean bean = converter.convertToBean(role, RoleBean.class);

		return bean;
	}

	@Override
	public void saveRole(RoleBean role) {
		Role roleEntity = converter.convertToEntity(role, Role.class);
		roleDao.save(roleEntity);
	}

	@Override
	public void deleteRole(Integer roleId) {
		roleDao.delete(roleId);
	}
}
