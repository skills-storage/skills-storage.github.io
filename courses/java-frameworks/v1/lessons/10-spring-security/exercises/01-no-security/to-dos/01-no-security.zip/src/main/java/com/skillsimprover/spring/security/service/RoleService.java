package com.skillsimprover.spring.security.service;

import com.skillsimprover.spring.security.beans.RoleBean;

public interface RoleService {

	Iterable<RoleBean> getAllRoles();

	RoleBean getRoleById(Integer roleId);

	void saveRole(RoleBean event);

	void deleteRole(Integer roleId);
}
