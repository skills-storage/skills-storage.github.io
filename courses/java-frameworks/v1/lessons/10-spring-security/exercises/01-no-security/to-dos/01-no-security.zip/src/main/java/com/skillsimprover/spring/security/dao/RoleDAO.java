package com.skillsimprover.spring.security.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.skillsimprover.spring.security.entities.Role;

@Repository
public interface RoleDAO extends CrudRepository<Role, Integer> {
}
