DROP SCHEMA IF EXISTS `security_db`;

CREATE SCHEMA IF NOT EXISTS `security_db`;

USE `security_db`;

-- ******************** Table Definitions ******************** 
CREATE TABLE `users` (
	`id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
	`user_name` VARCHAR(255) NOT NULL,
	`password` VARCHAR(255) NOT NULL,
	`enabled` TINYINT
);

CREATE TABLE `roles` (
	`id` INTEGER NOT NULL PRIMARY KEY,
	`role_name` VARCHAR(255) NOT NULL,
	`role_desc` TEXT NOT NULL
);

CREATE TABLE `users_to_roles` (
	`fk_user_id` INTEGER NOT NULL,
	`fk_role_id` INTEGER NOT NULL,

	PRIMARY KEY(`fk_user_id`, `fk_role_id`),

	CONSTRAINT `fk_to_user` FOREIGN KEY (`fk_user_id`) REFERENCES `users` (`id`)
		ON DELETE CASCADE
		ON UPDATE CASCADE,

	CONSTRAINT `fk_to_role` FOREIGN KEY (`fk_role_id`) REFERENCES `roles` (`id`)
		ON DELETE CASCADE
		ON UPDATE CASCADE
);

-- ************************ Test Data for users table ************************ 
INSERT INTO `users` (`id`, `user_name`, `password`, `enabled`) VALUES (1, 'ivan', 'ivan_123', 1);
INSERT INTO `users` (`id`, `user_name`, `password`, `enabled`) VALUES (2, 'petr', 'petr_123', 1);
INSERT INTO `users` (`id`, `user_name`, `password`, `enabled`) VALUES (3, 'sidor', 'sidor_123', 1);


-- ************************ Test Data for roles table ************************ 
INSERT INTO `roles` (`id`, `role_name`, `role_desc`) VALUES (1, 'administrator', 'Role for Administrators');
INSERT INTO `roles` (`id`, `role_name`, `role_desc`) VALUES (2, 'moderator', 'Role for Moderators');
INSERT INTO `roles` (`id`, `role_name`, `role_desc`) VALUES (3, 'regular_user', 'Role for Regular Users');


-- ************************ Test Data for users_to_roles table ************************ 
INSERT INTO `users_to_roles` (`fk_user_id`, `fk_role_id`) VALUES(1, 1);
INSERT INTO `users_to_roles` (`fk_user_id`, `fk_role_id`) VALUES(1, 2);
INSERT INTO `users_to_roles` (`fk_user_id`, `fk_role_id`) VALUES(1, 3);

INSERT INTO `users_to_roles` (`fk_user_id`, `fk_role_id`) VALUES(2, 2);
INSERT INTO `users_to_roles` (`fk_user_id`, `fk_role_id`) VALUES(2, 3);

INSERT INTO `users_to_roles` (`fk_user_id`, `fk_role_id`) VALUES(3, 3);
