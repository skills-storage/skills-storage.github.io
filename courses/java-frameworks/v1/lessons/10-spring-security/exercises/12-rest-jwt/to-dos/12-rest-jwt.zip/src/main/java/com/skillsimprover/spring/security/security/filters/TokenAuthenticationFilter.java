package com.skillsimprover.spring.security.security.filters;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;

import com.skillsimprover.spring.security.security.authhandlers.RestAuthenticationFailureHandler;
import com.skillsimprover.spring.security.security.authhandlers.RestAuthenticationSuccessHandler;
import com.skillsimprover.spring.security.security.beans.TokenAuthentication;

public class TokenAuthenticationFilter extends AbstractAuthenticationProcessingFilter {

	protected TokenAuthenticationFilter() {
		super("/api/**");

		setAuthenticationSuccessHandler(new RestAuthenticationSuccessHandler());
		setAuthenticationFailureHandler(new RestAuthenticationFailureHandler());
	}

	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, 
												HttpServletResponse response) throws AuthenticationException, 
                                                                                     IOException, 
                                                                                     ServletException {

		String token = request.getHeader("Authorization");
        if (token == null) {
            TokenAuthentication authentication = new TokenAuthentication(null);
            authentication.setAuthenticated(false);
            return authentication;
        }

        TokenAuthentication tokenAuthentication = new TokenAuthentication(token);
        Authentication authentication = getAuthenticationManager().authenticate(tokenAuthentication);
        return authentication;	
	}
}
