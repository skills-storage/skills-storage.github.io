package com.skillsimprover.spring.security.security.service;

import java.security.Key;

public interface TokenService {

	String getToken(String username, String password);

	Key getSecretKey();
}
