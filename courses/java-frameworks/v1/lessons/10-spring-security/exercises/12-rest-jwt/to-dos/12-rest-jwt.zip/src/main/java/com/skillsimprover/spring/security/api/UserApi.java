package com.skillsimprover.spring.security.api;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.skillsimprover.spring.security.beans.UserBean;
import com.skillsimprover.spring.security.service.UserService;

@RestController
@RequestMapping(value = "/api/users",
                consumes = MediaType.APPLICATION_JSON_VALUE,
                produces = MediaType.APPLICATION_JSON_VALUE)
public class UserApi {

	@Autowired
	private UserService userService;

	@GetMapping
	public ResponseEntity<Iterable<UserBean>> getAllUsers() {
		Iterable<UserBean> allUsers = userService.getAllUsers();
		ResponseEntity<Iterable<UserBean>> response = new ResponseEntity<>(allUsers, HttpStatus.OK);

		return response;
	}

	@GetMapping
	@RequestMapping("/{user_id}")
	public  ResponseEntity<UserBean>  getUserById(@PathVariable("user_id") Integer userId) {
		UserBean user = userService.getUserById(userId);
		ResponseEntity<UserBean> response = new ResponseEntity<>(user, HttpStatus.OK);

		return response;
	}

	@PutMapping
	public ResponseEntity<Void> saveUser(@Valid @RequestBody UserBean user, BindingResult bindingResult) {
		
		if (bindingResult.hasErrors()) {
			throw new RuntimeException("Invalid Input Parameters");
		}

		userService.saveUser(user);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PostMapping
	public ResponseEntity<Void> updateUser(@RequestBody UserBean user) {
		userService.saveUser(user);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@DeleteMapping
	public ResponseEntity<Void> deleteUser() {
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
