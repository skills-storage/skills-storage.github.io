package com.skillsimprover.spring.security.security.providers;

import java.security.Key;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetailsService;

import com.skillsimprover.spring.security.security.beans.LoggedAccountBean;
import com.skillsimprover.spring.security.security.beans.TokenAuthentication;
import com.skillsimprover.spring.security.security.service.TokenService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.impl.DefaultClaims;

public class TokenAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	private TokenService tokenService;

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		if (authentication instanceof TokenAuthentication) {
			TokenAuthentication readyTokenAuthentication = processAuthentication((TokenAuthentication) authentication);
			return readyTokenAuthentication;
		}

		authentication.setAuthenticated(false);
		return authentication;
	}

	private TokenAuthentication processAuthentication(TokenAuthentication authentication) throws AuthenticationException {
		String token = authentication.getToken();
		DefaultClaims claims;

		try {
			Key key = tokenService.getSecretKey();
			claims = (DefaultClaims) Jwts.parser().setSigningKey(key).parse(token).getBody();
		} catch (Exception ex) {
			throw new AuthenticationServiceException("Token corrupted");
		}

		if (claims.get("token_expiration_date", Long.class) == null) {
			throw new AuthenticationServiceException("Invalid token");
		}

		Date expiredDate = new Date(claims.get("token_expiration_date", Long.class));
		if (expiredDate.after(new Date())) {
			return buildFullTokenAuthentication(authentication, claims);
		}

		throw new AuthenticationServiceException("Token expired date error");
	}

	private TokenAuthentication buildFullTokenAuthentication(TokenAuthentication authentication, DefaultClaims claims) {
		LoggedAccountBean user = (LoggedAccountBean) userDetailsService.loadUserByUsername(claims.get("username", String.class));
		if (user.isEnabled()) {
			TokenAuthentication fullTokenAuthentication = new TokenAuthentication(authentication.getToken(), user, true);
			return fullTokenAuthentication;
		}

		throw new AuthenticationServiceException("User disabled");
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return true;
	}
}
