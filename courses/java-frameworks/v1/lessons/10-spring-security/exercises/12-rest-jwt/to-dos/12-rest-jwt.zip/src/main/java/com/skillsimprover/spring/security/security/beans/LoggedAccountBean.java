package com.skillsimprover.spring.security.security.beans;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.skillsimprover.spring.security.beans.UserBean;

public class LoggedAccountBean implements UserDetails {

	private static final long serialVersionUID = 1L;

	private UserBean user;

	private Collection<GrantedAuthorityBean> authorities;

	public LoggedAccountBean(UserBean user, Collection<GrantedAuthorityBean> authorities) {
		this.user = user;
		this.authorities = authorities;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}

	@Override
	public String getPassword() {
		return user.getPassword();
	}

	@Override
	public String getUsername() {
		return user.getUserName();
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO: implement real logic...
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO: implement real logic...
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO: implement real logic...
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	public Integer getUserId() {
		return user.getId();
	}
}
