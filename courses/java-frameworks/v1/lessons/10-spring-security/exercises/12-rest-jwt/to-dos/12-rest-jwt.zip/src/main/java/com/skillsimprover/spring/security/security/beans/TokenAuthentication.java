package com.skillsimprover.spring.security.security.beans;

import java.util.Collection;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class TokenAuthentication implements Authentication {

	private static final long serialVersionUID = 1L;

	private String token;

	private UserDetails userDetails;

	private boolean authenticated;

	public TokenAuthentication(String token) {
        if (token != null && token.startsWith("Bearer ")) {
            this.token = token.substring(7);
        } else {
        	this.token = token;
        }
	}

	public TokenAuthentication(String token, UserDetails userDetails, boolean authenticated) {
		super();
		this.token = token;
		this.userDetails = userDetails;
		this.authenticated = authenticated;
	}

	@Override
	public String getName() {
		if (userDetails == null) {
			return null;
		}

		return userDetails.getUsername();
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		if (userDetails == null) {
			return null;
		}

		return userDetails.getAuthorities();
	}

	@Override
	public Object getCredentials() {
		if (userDetails == null) {
			return null;
		}

		return userDetails.getPassword();
	}

	@Override
	public Object getDetails() {
		return userDetails;
	}

	@Override
	public Object getPrincipal() {
		return userDetails;
	}

	@Override
	public boolean isAuthenticated() {
		return authenticated;
	}

	@Override
	public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {
		authenticated = isAuthenticated;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
}
