package com.skillsimprover.spring.security.security.service.impl;

import java.security.Key;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.spring.security.security.beans.LoggedAccountBean;
import com.skillsimprover.spring.security.security.service.TokenService;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Service
@Transactional
public class TokenServiceImpl implements TokenService {

	private static final Key secretKey = Keys.secretKeyFor(SignatureAlgorithm.HS256);

    @Autowired
    private UserDetailsService userDetailsService;

	@Override
	public String getToken(String username, String password) {
		if (username == null || password == null) {
			return null;
		}

		LoggedAccountBean user = (LoggedAccountBean) userDetailsService.loadUserByUsername(username);
		if (!password.equals(user.getPassword())) {
			throw new RuntimeException("Authentication error");
		}

        Map<String, Object> tokenData = new HashMap<>();
        tokenData.put("clientType", "user");
        tokenData.put("userID", user.getUserId().toString());
        tokenData.put("username", user.getUsername());
        tokenData.put("token_create_date", new Date().getTime());
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, 100);
        tokenData.put("token_expiration_date", calendar.getTime());

        JwtBuilder jwtBuilder = Jwts.builder();
        jwtBuilder.setExpiration(calendar.getTime());
        jwtBuilder.setClaims(tokenData);

        Key key = getSecretKey();

        String token = jwtBuilder/*.setSubject(keyString)*/.signWith(key).compact();

        return token;
	}

	@Override
	public Key getSecretKey() {
		return secretKey;
	}
}
