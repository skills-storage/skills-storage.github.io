package com.skillsimprover.spring.security.security.providers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;

public class UserPasswordAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		String userName = authentication.getName();

		UserDetails loggedAccount = userDetailsService.loadUserByUsername(userName);
		String password = (String) authentication.getCredentials();

		String encodedPassword = loggedAccount.getPassword();

		if (!passwordEncoder.matches(password, encodedPassword)) {
			throw new BadCredentialsException("Wrong password.<br> Неправильный пароль");
		}

		if (!loggedAccount.isAccountNonLocked()) {
			throw new LockedException("User Account is locked!<br>Аккаунт заблокирован!", new Exception());
		}

		return new UsernamePasswordAuthenticationToken(loggedAccount, password, loggedAccount.getAuthorities());
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return true;
	}
}
