package com.skillsimprover.spring.security.security.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.spring.security.beans.RoleBean;
import com.skillsimprover.spring.security.beans.UserBean;
import com.skillsimprover.spring.security.security.beans.GrantedAuthorityBean;
import com.skillsimprover.spring.security.security.beans.LoggedAccountBean;
import com.skillsimprover.spring.security.service.UserService;

@Service
@Transactional
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private UserService userService;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UserBean user = userService.getUserByUserName(username);
		List<RoleBean> roles = user.getRoles();

		Collection<GrantedAuthorityBean> authorities = getUserAuthorities(roles);

		LoggedAccountBean loggedAccount = new LoggedAccountBean(user, authorities);

		return loggedAccount;
	}

	private Collection<GrantedAuthorityBean> getUserAuthorities(List<RoleBean> roles) {
		Collection<GrantedAuthorityBean> authorities = new ArrayList<>();

		for (RoleBean role : roles) {
			GrantedAuthorityBean bean = new GrantedAuthorityBean(role.getName());
			authorities.add(bean);
		}

		return authorities;
	}
}
