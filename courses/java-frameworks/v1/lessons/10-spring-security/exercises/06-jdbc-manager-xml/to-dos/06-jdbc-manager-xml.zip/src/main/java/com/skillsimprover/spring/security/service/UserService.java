package com.skillsimprover.spring.security.service;

import com.skillsimprover.spring.security.beans.UserBean;

public interface UserService {

	Iterable<UserBean> getAllUsers();

	UserBean getUserById(Integer userId);

	void saveUser(UserBean user);

	void deleteUser(Integer userId);
}
