package com.skillsimprover.jpa.beans;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class VisitEventBean {

	private Integer id;

	private String eventName;

	private Date eventDate;

	public VisitEventBean() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public Date getEventDate() {
		return eventDate;
	}

	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}

	public String getEventInfo() {
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		String dateStr = dateFormat.format(eventDate);

		return dateStr + " - " + eventName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((eventName == null) ? 0 : eventName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		if (getClass() != obj.getClass()) {
			return false;
		}

		VisitEventBean other = (VisitEventBean) obj;
		if (eventName == null) {
			if (other.eventName != null) {
				return false;
			}
		} else if (!eventName.equals(other.eventName)) {
			return false;
		}

		return true;
	}

	@Override
	public String toString() {
		return "VisitEventBean [id=" + id + ", eventName=" + eventName + ", eventDate=" + eventDate + "]";
	}
}
