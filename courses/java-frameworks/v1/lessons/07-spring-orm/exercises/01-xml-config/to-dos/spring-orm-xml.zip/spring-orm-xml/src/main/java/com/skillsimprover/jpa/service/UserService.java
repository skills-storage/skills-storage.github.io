package com.skillsimprover.jpa.service;

import java.util.List;

import com.skillsimprover.jpa.beans.UserBean;

public interface UserService {

	List<UserBean> getAllUsers();

	UserBean getUserById(Integer userId);

	void saveUser(UserBean user);

	void deleteUser(Integer userId);
}
