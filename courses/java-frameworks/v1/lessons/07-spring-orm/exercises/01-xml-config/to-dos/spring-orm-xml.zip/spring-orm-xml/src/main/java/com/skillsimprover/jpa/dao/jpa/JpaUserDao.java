package com.skillsimprover.jpa.dao.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.skillsimprover.jpa.dao.UserDAO;
import com.skillsimprover.jpa.entities.User;

@Repository
public class JpaUserDao implements UserDAO {

	@PersistenceContext
	private EntityManager manager;

	@Override
	public List<User> loadAllUsers() {
		List<User> result = manager.createQuery( "from User", User.class ).getResultList();
		return result;
	}

	@Override
	public User loadUserById(Integer userId) {
		User user = manager.find(User.class, userId);
		return user;
	}

	@Override
	public User loadUserByUsername(String userName) {
		Query query = manager.createNamedQuery("User.findByUserName");
		query.setParameter("userName", userName);
		User user = (User) query.getSingleResult();

		return user;
	}

	@Override
	public User storeUser(User user) {
		manager.merge(user);
		return user;
	}

	@Override
	public void deleteUser(Integer userId) {
		User user = manager.find(User.class, userId);
		manager.remove(user);
	}
}
