package com.skillsimprover.jpa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.jpa.beans.EventBean;
import com.skillsimprover.jpa.dao.EventDAO;
import com.skillsimprover.jpa.entities.Event;
import com.skillsimprover.jpa.service.EntityBeanConverter;
import com.skillsimprover.jpa.service.EventService;

@Service
@Transactional
public class EventServiceImpl implements EventService {

	@Autowired
	private EventDAO eventDao;

	@Autowired
	private EntityBeanConverter converter;

	@Override
	public List<EventBean> getAllEvents() {
		List<Event> events = eventDao.loadAllEvents();
		List<EventBean> beanList = converter.convertToBeanList(events, EventBean.class);

		return beanList;
	}

	@Override
	public EventBean getEventById(Integer eventId) {
		Event event = eventDao.loadEventById(eventId);
		EventBean bean = converter.convertToBean(event, EventBean.class);

		return bean;
	}

	@Override
	public void saveEvent(EventBean event) {
		Event eventEntity = converter.convertToEntity(event, Event.class);
		eventDao.storeEvent(eventEntity);
	}

	@Override
	public void deleteEvent(Integer eventId) {
		eventDao.deleteEvent(eventId);
	}
}
