package com.skillsimprover.jpa.dao;

import java.util.List;

import com.skillsimprover.jpa.entities.Event;

public interface EventDAO {

	List<Event> loadAllEvents();

	Event loadEventById(Integer eventId);

	Event storeEvent(Event event);

	void deleteEvent(Integer eventId);
}
