package com.skillsimprover.jpa.controllers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.skillsimprover.jpa.beans.EventBean;
import com.skillsimprover.jpa.beans.UserBean;
import com.skillsimprover.jpa.service.EventService;
import com.skillsimprover.jpa.service.UserService;

@Controller
public class EventController {

	@Autowired
	private EventService eventService;

	@Autowired
	private UserService userService;

	@RequestMapping("/events")
	public ModelAndView showEventsPage() {
		ModelAndView modelAndView = new ModelAndView("events");
		return modelAndView;
	}

	@RequestMapping("/update-event")
	public ModelAndView updateEvent(@RequestParam(name = "event_id") Integer eventId) {
		ModelAndView modelAndView = new ModelAndView("events");

		EventBean event = eventService.getEventById(eventId);
		modelAndView.addObject("event", event);

		return modelAndView;
	}

	@RequestMapping("/delete-event")
	public ModelAndView deleteEvent(@RequestParam(name = "event_id") Integer eventId) {
		eventService.deleteEvent(eventId);

		ModelAndView modelAndView = new ModelAndView("redirect:events");
		return modelAndView;
	}

	@RequestMapping(value = "/save-event", method = RequestMethod.POST)
	public ModelAndView saveEvent(EventBean event) {
		eventService.saveEvent(event);

		ModelAndView modelAndView = new ModelAndView("redirect:events");
		return modelAndView;
	}

	@ModelAttribute(name = "userList")
	private List<UserBean> getUserList() {
		List<UserBean> userList = userService.getAllUsers();
		return userList;
	}

	@ModelAttribute(name = "eventList")
	private List<EventBean> getEventList() {
		List<EventBean> eventList = eventService.getAllEvents();
		return eventList;
	}

	@ModelAttribute(name = "event")
	private EventBean getEmptyEvent() {
		return new EventBean();
	}

	@InitBinder
	public void initBinder(WebDataBinder webDataBinder) {
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		dateFormat.setLenient(false);
		webDataBinder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
}
