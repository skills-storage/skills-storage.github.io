package com.skillsimprover.usersapp.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.usersapp.beans.UserBean;
import com.skillsimprover.usersapp.dao.UserDAO;
import com.skillsimprover.usersapp.entities.User;
import com.skillsimprover.usersapp.service.EntityBeanConverter;
import com.skillsimprover.usersapp.service.UserService;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDao;

	@Autowired
	private EntityBeanConverter converter;

	@Override
	public List<UserBean> getAllUsers() {
		List<User> users = userDao.loadAllUsers();
		List<UserBean> beanList = converter.convertToBeanList(users, UserBean.class);

		return beanList;
	}

	@Override
	public UserBean getUserById(Integer userId) {
		User user = userDao.loadUserById(userId);
		UserBean bean = converter.convertToBean(user, UserBean.class);

		return bean;
	}

	@Override
	public void saveUser(UserBean user) {
		User userEntity = converter.convertToEntity(user, User.class);
		userDao.storeUser(userEntity);
	}

	@Override
	public void deleteUser(Integer userId) {
		userDao.deleteUser(userId);
	}
}
