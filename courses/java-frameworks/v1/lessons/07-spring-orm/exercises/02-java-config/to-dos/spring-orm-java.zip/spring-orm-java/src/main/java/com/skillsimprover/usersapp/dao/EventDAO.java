package com.skillsimprover.usersapp.dao;

import java.util.List;

import com.skillsimprover.usersapp.entities.Event;

public interface EventDAO {

	List<Event> loadAllEvents();

	Event loadEventById(Integer eventId);

	Event storeEvent(Event event);

	void deleteEvent(Integer eventId);
}
