package com.skillsimprover.usersapp.web.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.skillsimprover.usersapp.beans.UserBean;
import com.skillsimprover.usersapp.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	@RequestMapping("/users")
	public ModelAndView showUsersPage() {
		ModelAndView modelAndView = new ModelAndView("users");
		return modelAndView;
	}

	@RequestMapping("/update-user")
	public ModelAndView updateUser(@RequestParam(name = "user_id") Integer userId) {
		ModelAndView modelAndView = new ModelAndView("users");

		UserBean user = userService.getUserById(userId);
		modelAndView.addObject("user", user);

		return modelAndView;
	}

	@RequestMapping("/delete-user")
	public ModelAndView deleteUser(@RequestParam(name = "user_id") Integer userId) {
		userService.deleteUser(userId);

		ModelAndView modelAndView = new ModelAndView("redirect:users");
		return modelAndView;
	}

	@RequestMapping(value = "/save-user", method = RequestMethod.POST)
	public ModelAndView saveUser(UserBean user) {
		userService.saveUser(user);

		ModelAndView modelAndView = new ModelAndView("redirect:users");
		return modelAndView;
	}

	@ModelAttribute(name = "userList")
	private List<UserBean> getUserList() {
		List<UserBean> userList = userService.getAllUsers();
		return userList;
	}

	@ModelAttribute(name = "user")
	private UserBean getEmptyUser() {
		return new UserBean();
	}
}
