package com.skillsimprover.usersapp.dao;

import java.util.List;

import com.skillsimprover.usersapp.entities.User;

public interface UserDAO {

	List<User> loadAllUsers();

	User loadUserById(Integer userId);

	User loadUserByUsername(String userName);

	User storeUser(User user);

	void deleteUser(Integer userId);
}
