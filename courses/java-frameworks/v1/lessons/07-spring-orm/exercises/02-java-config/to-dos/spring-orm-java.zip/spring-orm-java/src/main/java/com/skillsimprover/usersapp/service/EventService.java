package com.skillsimprover.usersapp.service;

import java.util.List;

import com.skillsimprover.usersapp.beans.EventBean;

public interface EventService {

	List<EventBean> getAllEvents();

	EventBean getEventById(Integer eventId);

	void saveEvent(EventBean event);

	void deleteEvent(Integer eventId);
}
