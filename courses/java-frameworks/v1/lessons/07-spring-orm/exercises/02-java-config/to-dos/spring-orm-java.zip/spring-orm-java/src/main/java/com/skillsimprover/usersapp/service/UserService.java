package com.skillsimprover.usersapp.service;

import java.util.List;

import com.skillsimprover.usersapp.beans.UserBean;

public interface UserService {

	List<UserBean> getAllUsers();

	UserBean getUserById(Integer userId);

	void saveUser(UserBean user);

	void deleteUser(Integer userId);
}
