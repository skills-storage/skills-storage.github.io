package com.skillsimprover.usersapp.dao.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.skillsimprover.usersapp.dao.EventDAO;
import com.skillsimprover.usersapp.entities.Address;
import com.skillsimprover.usersapp.entities.Event;

@Repository
public class JpaEventDao implements EventDAO {

	@PersistenceContext
	private EntityManager manager;

	@Override
	public List<Event> loadAllEvents() {
		List<Event> result = manager.createQuery( "from Event", Event.class ).getResultList();
		return result;
	}

	@Override
	public Event loadEventById(Integer eventId) {
		Event event = manager.find(Event.class, eventId);
		return event;
	}

	@Override
	public Event storeEvent(Event event) {
		Address address = event.getAddress();
		address = manager.merge(address);

		event.setAddress(address);
		event.setId(address.getId());

		manager.merge(event);

		return event;
	}

	@Override
	public void deleteEvent(Integer eventId) {
		Event event = manager.find(Event.class, eventId);
		manager.remove(event);
	}
}
