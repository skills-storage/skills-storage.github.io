package com.skillsimprover.springorm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.springorm.beans.UserBean;
import com.skillsimprover.springorm.dao.UserDAO;
import com.skillsimprover.springorm.service.UserService;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDao;

	@Override
	public List<UserBean> getAllUsers() {
		List<UserBean> users = userDao.loadAllUsers();
		return users;
	}

	@Override
	public UserBean getUserById(Integer userId) {
		UserBean user = userDao.loadUserById(userId);
		return user;
	}

	@Override
	public void saveUser(UserBean user) {
		userDao.storeUser(user);
	}

	@Override
	public void deleteUser(Integer userId) {
		userDao.deleteUser(userId);
	}
}
