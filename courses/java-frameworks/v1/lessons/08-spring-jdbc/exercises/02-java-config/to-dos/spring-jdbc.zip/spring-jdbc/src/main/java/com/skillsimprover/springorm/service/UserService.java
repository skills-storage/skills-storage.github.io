package com.skillsimprover.springorm.service;

import java.util.List;

import com.skillsimprover.springorm.beans.UserBean;

public interface UserService {

	List<UserBean> getAllUsers();

	UserBean getUserById(Integer userId);

	void saveUser(UserBean user);

	void deleteUser(Integer userId);
}
