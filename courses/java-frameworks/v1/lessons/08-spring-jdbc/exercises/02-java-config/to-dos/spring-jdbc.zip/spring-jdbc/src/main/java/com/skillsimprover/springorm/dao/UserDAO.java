package com.skillsimprover.springorm.dao;

import java.util.List;

import com.skillsimprover.springorm.beans.UserBean;

public interface UserDAO {

	List<UserBean> loadAllUsers();

	UserBean loadUserById(Integer userId);

	UserBean loadUserByUsername(String userName);

	void storeUser(UserBean user);

	void deleteUser(Integer userId);
}
