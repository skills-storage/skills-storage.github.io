package com.skillsimprover.springorm.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.springorm.beans.UserBean;
import com.skillsimprover.springorm.dao.UserDAO;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public class JdbcUserDao implements UserDAO {

	@Autowired
	private DataSource dataSource;

	@Override
	public List<UserBean> loadAllUsers() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		List<UserBean> users = jdbcTemplate.query("SELECT id, user_name, password FROM users", getUserMapper()); 
		return users;
	}

	@Override
	public UserBean loadUserById(Integer userId) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		UserBean user = jdbcTemplate.queryForObject("SELECT id, user_name, password FROM users WHERE id = ?", getUserMapper(), userId);
		return user;
	}

	@Override
	public UserBean loadUserByUsername(String userName) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		UserBean user = jdbcTemplate.queryForObject("SELECT id, user_name, password FROM users WHERE user_name = ?", getUserMapper(), userName);
		return user;
	}

	@Override
	public void storeUser(UserBean user) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.update("INSERT INTO users (user_name, password) VALUES (?, ?)", user.getUserName(), user.getPassword());
	}

	@Override
	public void deleteUser(Integer userId) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.update("DELETE FROM users where id = ?", userId);
	}

	private RowMapper<UserBean> getUserMapper() {
		return new RowMapper<UserBean>() {

			@Override
			public UserBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("id"));
				userBean.setUserName(rs.getString("user_name"));
				userBean.setPassword(rs.getString("password"));

				return userBean;
			}
		};
	}
}
