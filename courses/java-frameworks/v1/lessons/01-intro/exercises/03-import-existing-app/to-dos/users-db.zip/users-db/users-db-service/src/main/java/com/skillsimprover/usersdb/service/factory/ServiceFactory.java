package com.skillsimprover.usersdb.service.factory;

import com.skillsimprover.usersdb.service.UserService;

public abstract class ServiceFactory {

	public abstract UserService getUserService();

	public static ServiceFactory getServiceFactory() {
		return new ServiceFactoryImpl();
	}
}
