package com.skillsimprover.usersdb.dao.factory;

import com.skillsimprover.usersdb.dao.UserDao;

public abstract class DAOFactory {

	public abstract UserDao getUserDao();

	public static DAOFactory getDaoFactory() {
		return getDaoFactory(FactoryTypes.Jdbc);
	}

	public static DAOFactory getDaoFactory(FactoryTypes type) {
		switch (type) {
		case Jdbc:
			return new JdbcDaoFactory();
		default:
			throw new IllegalStateException("You tried to get unsupported storadge type!");
		}
	}
}
