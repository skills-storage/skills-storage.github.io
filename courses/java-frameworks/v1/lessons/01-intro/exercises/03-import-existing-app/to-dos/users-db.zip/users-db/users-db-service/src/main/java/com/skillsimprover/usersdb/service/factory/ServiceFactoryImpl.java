package com.skillsimprover.usersdb.service.factory;

import com.skillsimprover.usersdb.service.UserService;
import com.skillsimprover.usersdb.service.impl.UserServiceImpl;

public class ServiceFactoryImpl extends ServiceFactory {

	ServiceFactoryImpl() {
		super();
	}

	@Override
	public UserService getUserService() {
		return new UserServiceImpl();
	}
}
