package com.skillsimprover.usersdb.dao.factory;

public enum FactoryTypes {

	Jdbc;
}
