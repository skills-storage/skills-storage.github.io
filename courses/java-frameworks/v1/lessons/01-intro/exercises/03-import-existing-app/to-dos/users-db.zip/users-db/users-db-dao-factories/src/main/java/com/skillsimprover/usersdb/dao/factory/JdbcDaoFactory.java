package com.skillsimprover.usersdb.dao.factory;

import com.skillsimprover.usersdb.dao.UserDao;

public class JdbcDaoFactory extends DAOFactory {

	JdbcDaoFactory() {
		super();
	}

	@Override
	public UserDao getUserDao() {
		Object dao = loadDaoObjectByName("com.skillsimprover.usersdb.dao.jdbc.UserDaoImpl");
		UserDao userDao = ((UserDao) dao);

		return userDao;
	}

	private Object loadDaoObjectByName(String daoClassName) {
		try {
			Class<?> daoClass = Class.forName(daoClassName);
			Object daoObject = daoClass.newInstance();

			return daoObject;
		} catch (Exception e) {
			throw new RuntimeException("Can not load DAO class for name: " + daoClassName, e);
		}
	}
}
