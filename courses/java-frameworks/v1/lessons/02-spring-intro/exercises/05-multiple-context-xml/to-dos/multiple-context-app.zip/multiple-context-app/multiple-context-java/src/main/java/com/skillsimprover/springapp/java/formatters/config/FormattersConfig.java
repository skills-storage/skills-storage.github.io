package com.skillsimprover.springapp.java.formatters.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.skillsimprover.springapp.java.formatters.impl")
public class FormattersConfig {

}
