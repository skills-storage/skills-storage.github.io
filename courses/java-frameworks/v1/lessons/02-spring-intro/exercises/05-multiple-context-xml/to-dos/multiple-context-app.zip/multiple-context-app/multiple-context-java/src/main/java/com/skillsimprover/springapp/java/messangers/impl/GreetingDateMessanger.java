package com.skillsimprover.springapp.java.messangers.impl;

import java.text.DateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.skillsimprover.springapp.java.messangers.Messanger;

@Component
public class GreetingDateMessanger implements Messanger {

	private String message;

	private DateFormat dateFormatter;

	@Autowired
	public GreetingDateMessanger(String message, DateFormat dateFormatter) {
		super();
		this.message = message;
		this.dateFormatter = dateFormatter;
	}

	@Override
	public String getMessage() {
		Date today = getToday();
		String todayStr = dateFormatter.format(today);

		return message + " printed at: " + todayStr;
	}

	private Date getToday() {
		return new Date();
	}
}
