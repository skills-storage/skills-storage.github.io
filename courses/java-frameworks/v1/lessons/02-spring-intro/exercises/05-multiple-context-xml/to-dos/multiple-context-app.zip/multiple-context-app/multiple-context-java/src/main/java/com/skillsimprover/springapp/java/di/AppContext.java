package com.skillsimprover.springapp.java.di;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.skillsimprover.springapp.java.AppConfig;

public final class AppContext {

	private static final AppContext CONTEXT = new AppContext();

	private final AnnotationConfigApplicationContext applicationContext;

	private AppContext() {
		applicationContext = new AnnotationConfigApplicationContext();
		applicationContext.register(AppConfig.class);
		applicationContext.refresh();
	}

	public static AppContext getContext() {
		return CONTEXT;
	}

	@SuppressWarnings("unchecked")
	public <T> T getBean(String beanName) {
		return (T) applicationContext.getBean(beanName);
	}

	@SuppressWarnings("unchecked")
	public <T> T getBean(Class<?> requiredType) {
		return (T) applicationContext.getBean(requiredType);
	}

	public void destroy() {
		applicationContext.close();
	}
}
