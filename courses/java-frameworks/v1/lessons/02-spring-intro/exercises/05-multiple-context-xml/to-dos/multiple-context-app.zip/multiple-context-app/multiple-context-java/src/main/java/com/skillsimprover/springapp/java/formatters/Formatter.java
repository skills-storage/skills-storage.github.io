package com.skillsimprover.springapp.java.formatters;

public interface Formatter {

	String formatMessage();
}





