package com.skillsimprover.multiple.context.xml.formatters.impl;

import com.skillsimprover.multiple.context.xml.formatters.Formatter;
import com.skillsimprover.multiple.context.xml.messangers.Messanger;

public class StarFormatter implements Formatter {

	private Messanger messanger;

	@Override
	public String formatMessage() {
		StringBuilder builder = new StringBuilder();

		builder.append("********************************************************************");
		builder.append("\n");
		builder.append("\t\t\t");
		builder.append(messanger.getMessage());
		builder.append("\n");
		builder.append("********************************************************************");

		return builder.toString();
	}

	public void setMessanger(Messanger messanger) {
		this.messanger = messanger;
	}
}