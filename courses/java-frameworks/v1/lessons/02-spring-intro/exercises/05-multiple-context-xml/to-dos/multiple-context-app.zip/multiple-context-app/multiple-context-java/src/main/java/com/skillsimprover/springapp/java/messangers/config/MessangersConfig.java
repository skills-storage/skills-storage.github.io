package com.skillsimprover.springapp.java.messangers.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.skillsimprover.springapp.java.messangers.impl")
public class MessangersConfig {

}
