package com.skillsimprover.multiple.context.xml.messangers.impl;

import com.skillsimprover.multiple.context.xml.messangers.Messanger;

public class GreetingMessanger implements Messanger {

	private String message;

	public GreetingMessanger(String message) {
		super();
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}
}
