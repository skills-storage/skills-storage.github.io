package com.skillsimprover.springapp.java;

import com.skillsimprover.springapp.java.di.AppContext;
import com.skillsimprover.springapp.java.formatters.Formatter;

public class GreetingApp {

    public static void main( String[] args ) {

    	AppContext appContext = AppContext.getContext();

    	Formatter formatter = appContext.getBean("dollarFormatter");

    	System.out.println(formatter.formatMessage());

    	appContext.destroy();
    }
}
