package com.skillsimprover.multiple.context.xml.formatters;

public interface Formatter {

	String formatMessage();
}





