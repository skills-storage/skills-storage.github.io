package com.skillsimprover.multiple.context.xml.di;

import org.springframework.context.support.FileSystemXmlApplicationContext;

public final class AppContext {

	private static final AppContext CONTEXT = new AppContext();

	private static final String APP_CONTEXT_FILE = "classpath:com/skillsimprover/multiple/contexts/app-config-main.xml";

	private final FileSystemXmlApplicationContext applicationContext;

	private AppContext() {
		applicationContext = new FileSystemXmlApplicationContext(APP_CONTEXT_FILE);
	}

	public static AppContext getContext() {
		return CONTEXT;
	}

	@SuppressWarnings("unchecked")
	public <T> T getBean(String beanName) {
		return (T) applicationContext.getBean(beanName);
	}

	@SuppressWarnings("unchecked")
	public <T> T getBean(Class<?> requiredType) {
		return (T) applicationContext.getBean(requiredType);
	}

	public void destroy() {
		applicationContext.close();
	}
}
