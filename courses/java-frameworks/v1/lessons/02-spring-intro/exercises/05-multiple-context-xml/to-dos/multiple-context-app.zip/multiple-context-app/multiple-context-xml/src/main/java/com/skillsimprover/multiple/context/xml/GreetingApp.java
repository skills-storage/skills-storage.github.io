package com.skillsimprover.multiple.context.xml;

import com.skillsimprover.multiple.context.xml.di.AppContext;
import com.skillsimprover.multiple.context.xml.formatters.Formatter;

public class GreetingApp {

    public static void main( String[] args ) {

    	AppContext appContext = AppContext.getContext();

    	Formatter formatter = appContext.getBean("defaultFormatter");

    	System.out.println(formatter.formatMessage());

    	appContext.destroy();
    }
}
