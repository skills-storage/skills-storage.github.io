package com.skillsimprover.multiple.context.xml.messangers;

public interface Messanger {

	String getMessage();
}
