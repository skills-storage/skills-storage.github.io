package com.skillsimprover.springapp.java;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.skillsimprover.springapp.java.formatters.config.FormattersConfig;
import com.skillsimprover.springapp.java.messangers.config.MessangersConfig;

@Import({
	MessangersConfig.class,
	FormattersConfig.class
})

@Configuration
public class AppConfig {

    @Bean
    public String message() {
    	return "This ia a message from Java Config!";
    }

    @Bean
    public DateFormat dateFormat() {
    	return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    }
}
