package com.skillsimprover.nospringapp.formatters;

import com.skillsimprover.nospringapp.messangers.GreetingMessanger;

public class DashFormatter {

	public String formatMessage(GreetingMessanger messanger) {
		StringBuilder builder = new StringBuilder();

		builder.append("--------------------------------------------------------------------");
		builder.append("\n");
		builder.append("\t\t\t");
		builder.append(messanger.getMessage());
		builder.append("\n");
		builder.append("--------------------------------------------------------------------");

		return builder.toString();
	}
}
