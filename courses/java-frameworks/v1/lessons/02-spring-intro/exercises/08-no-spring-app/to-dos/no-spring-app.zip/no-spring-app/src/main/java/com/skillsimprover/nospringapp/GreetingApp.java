package com.skillsimprover.nospringapp;

import com.skillsimprover.nospringapp.formatters.DashFormatter;
import com.skillsimprover.nospringapp.messangers.GreetingMessanger;

public class GreetingApp {

	public static void main( String[] args ) {
    	GreetingMessanger messanger = new GreetingMessanger();
    	DashFormatter formatter = new DashFormatter();

    	String greetingMessage = formatter.formatMessage(messanger);

    	System.out.println(greetingMessage);
    }
}
