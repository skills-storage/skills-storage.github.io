package com.skillsimprover.nospringapp.messangers;

public class GreetingMessanger {

	public String getMessage() {
		return "Our application says HELLO!";
	}
}
