package com.skillsimprover.springapp.bpp.formatters.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.skillsimprover.springapp.bpp.formatters.Formatter;
import com.skillsimprover.springapp.bpp.messangers.Messanger;

@Component("starFormatter")
public class StarFormatter implements Formatter {

	@Autowired
	private Messanger messanger;

	@Override
	public String formatMessage() {
		StringBuilder builder = new StringBuilder();

		builder.append("********************************************************************");
		builder.append("\n");
		builder.append("\t\t\t");
		builder.append(messanger.getMessage());
		builder.append("\n");
		builder.append("********************************************************************");

		return builder.toString();
	}

	public void setMessanger(Messanger messanger) {
		this.messanger = messanger;
	}
}