package com.skillsimprover.springapp.annotations.formatters;

public interface Formatter {

	String formatMessage();
}





