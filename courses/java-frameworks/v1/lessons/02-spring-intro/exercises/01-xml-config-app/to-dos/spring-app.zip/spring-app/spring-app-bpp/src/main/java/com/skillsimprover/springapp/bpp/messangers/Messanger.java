package com.skillsimprover.springapp.bpp.messangers;

public interface Messanger {

	String getMessage();
}
