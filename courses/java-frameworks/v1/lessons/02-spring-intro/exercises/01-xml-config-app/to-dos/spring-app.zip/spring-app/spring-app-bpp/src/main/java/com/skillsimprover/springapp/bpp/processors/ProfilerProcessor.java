package com.skillsimprover.springapp.bpp.processors;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.skillsimprover.springapp.bpp.annotations.Profiler;

public class ProfilerProcessor implements BeanPostProcessor {

	Map<String, Class<?>> profilerBeans = new HashMap<>();

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		Class<?> beanClass = bean.getClass();
		if (beanClass.isAnnotationPresent(Profiler.class)) {
			profilerBeans.put(beanName, beanClass);
		}

		return bean;
	}

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		Class<?> beanClass = profilerBeans.get(beanName);
		if (beanClass == null) {
			return bean;
		}

		Object beanProxy = Proxy.newProxyInstance(beanClass.getClassLoader(), beanClass.getInterfaces(), new InvocationHandler() {

			@Override
			public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
				long start = System.nanoTime();
				System.out.printf("Profiler: Method - %s - started at: %s\n", method.getName(), start);
				
				Object result = method.invoke(bean, args);
				
				long finish = System.nanoTime();
				long delta = finish - start;
				
				System.out.printf("Profiler: Method - %s - finished at: %s. Invocation time: %s\n", method.getName(), finish, delta);
				
				return result;
			}
		});

		return beanProxy;
	}
}
