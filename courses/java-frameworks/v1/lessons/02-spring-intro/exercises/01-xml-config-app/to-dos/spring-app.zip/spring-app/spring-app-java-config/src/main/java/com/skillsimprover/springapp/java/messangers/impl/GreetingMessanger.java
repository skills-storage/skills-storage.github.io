package com.skillsimprover.springapp.java.messangers.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.skillsimprover.springapp.java.messangers.Messanger;

@Component
public class GreetingMessanger implements Messanger {

	private String message;

	@Autowired
	public GreetingMessanger(String message) {
		super();
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}
}
