package com.skillsimprover.springapp.annotations.messangers.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skillsimprover.springapp.annotations.messangers.Messanger;

@Service
public class GreetingMessanger implements Messanger {

	@Autowired
	private String message;

	public GreetingMessanger(String message) {
		super();
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}
}
