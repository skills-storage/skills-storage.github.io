package com.skillsimprover.springapp.xml.formatters;

public interface Formatter {

	String formatMessage();
}





