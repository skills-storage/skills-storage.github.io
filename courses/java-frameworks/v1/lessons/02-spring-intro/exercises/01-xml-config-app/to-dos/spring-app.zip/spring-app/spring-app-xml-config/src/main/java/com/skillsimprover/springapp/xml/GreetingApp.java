package com.skillsimprover.springapp.xml;

import com.skillsimprover.springapp.xml.di.AppContext;
import com.skillsimprover.springapp.xml.formatters.Formatter;

public class GreetingApp {

    public static void main( String[] args ) {

    	AppContext appContext = AppContext.getContext();

    	Formatter formatter = appContext.getBean("defaultFormatter");

    	System.out.println(formatter.formatMessage());

    	appContext.destroy();
    }
}
