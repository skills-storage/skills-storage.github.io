package com.skillsimprover.springapp.bpp.test;

public interface Test {

	void test();
}
