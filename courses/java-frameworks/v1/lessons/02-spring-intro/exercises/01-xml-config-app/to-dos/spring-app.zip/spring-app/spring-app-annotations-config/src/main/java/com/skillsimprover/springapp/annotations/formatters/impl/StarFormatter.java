package com.skillsimprover.springapp.annotations.formatters.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.skillsimprover.springapp.annotations.formatters.Formatter;
import com.skillsimprover.springapp.annotations.messangers.Messanger;

@Service
public class StarFormatter implements Formatter {

	@Qualifier("greetingDateMessanger")
	private Messanger messanger;

	@Autowired
	public StarFormatter(@Qualifier("greetingDateMessanger") Messanger messanger) {
		super();
		this.messanger = messanger;
	}

	@Override
	public String formatMessage() {
		StringBuilder builder = new StringBuilder();

		builder.append("********************************************************************");
		builder.append("\n");
		builder.append("\t\t\t");
		builder.append(messanger.getMessage());
		builder.append("\n");
		builder.append("********************************************************************");

		return builder.toString();
	}

	public void setMessanger(Messanger messanger) {
		this.messanger = messanger;
	}
}
