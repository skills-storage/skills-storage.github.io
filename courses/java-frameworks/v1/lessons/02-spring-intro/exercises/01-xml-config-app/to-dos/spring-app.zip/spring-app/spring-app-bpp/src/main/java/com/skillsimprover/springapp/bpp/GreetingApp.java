package com.skillsimprover.springapp.bpp;

import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;

import com.skillsimprover.springapp.bpp.di.AppContext;
import com.skillsimprover.springapp.bpp.formatters.Formatter;
import com.skillsimprover.springapp.bpp.processors.LocalizedMessageProcessor;
import com.skillsimprover.springapp.bpp.processors.ProfilerProcessor;
import com.skillsimprover.springapp.bpp.processors.TestBeanPostProcessor;
import com.skillsimprover.springapp.bpp.test.Test;
import com.skillsimprover.springapp.bpp.test.impl.TestImpl;

@Configuration
@ComponentScans({
	@ComponentScan("com.skillsimprover.springapp.bpp.messangers.impl"),
	@ComponentScan("com.skillsimprover.springapp.bpp.formatters.impl")
})
public class GreetingApp {

    public static void main( String[] args ) {

    	AppContext appContext = AppContext.getContext();

    	Formatter formatter = appContext.getBean("dollarFormatter");

    	System.out.println(formatter.formatMessage());

    	appContext.destroy();
    	
    	System.gc();
    }

    @Bean(name = "testBean", initMethod = "init", destroyMethod = "destroy")
    public Test createTestBean() {
    	return new TestImpl();
    }

    @Bean
    public BeanPostProcessor getTestBpp() {
    	return new TestBeanPostProcessor();
    }

    @Bean
    public BeanPostProcessor getLocalizedMessagesProcessor() {
    	return new LocalizedMessageProcessor();
    }

    @Bean
    public BeanPostProcessor getProfilerProcessor() {
    	return new ProfilerProcessor();
    }
}
