package com.skillsimprover.springapp.xml.messangers.impl;

import com.skillsimprover.springapp.xml.messangers.Messanger;

public class GreetingMessanger implements Messanger {

	private String message;

	public GreetingMessanger(String message) {
		super();
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}
}
