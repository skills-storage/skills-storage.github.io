package com.skillsimprover.springapp.annotations.messangers;

public interface Messanger {

	String getMessage();
}
