package com.skillsimprover.springapp.xml.messangers;

public interface Messanger {

	String getMessage();
}
