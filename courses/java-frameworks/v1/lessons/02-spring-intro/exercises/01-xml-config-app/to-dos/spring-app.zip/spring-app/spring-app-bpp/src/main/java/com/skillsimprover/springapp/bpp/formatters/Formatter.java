package com.skillsimprover.springapp.bpp.formatters;

public interface Formatter {

	String formatMessage();
}





