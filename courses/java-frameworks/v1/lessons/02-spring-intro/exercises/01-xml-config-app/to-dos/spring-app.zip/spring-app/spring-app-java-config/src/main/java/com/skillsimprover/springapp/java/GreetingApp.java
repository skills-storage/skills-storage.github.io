package com.skillsimprover.springapp.java;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;

import com.skillsimprover.springapp.java.di.AppContext;
import com.skillsimprover.springapp.java.formatters.Formatter;

@Configuration

@ComponentScans({
	@ComponentScan("com.skillsimprover.springapp.java.messangers.impl"),
	@ComponentScan("com.skillsimprover.springapp.java.formatters.impl")
})
public class GreetingApp {

    public static void main( String[] args ) {

    	AppContext appContext = AppContext.getContext();

    	Formatter formatter = appContext.getBean("dollarFormatter");

    	System.out.println(formatter.formatMessage());

    	appContext.destroy();
    }

    @Bean
    public String message() {
    	return "This ia a message from Java Config!";
    }

    @Bean
    public DateFormat dateFormat() {
    	return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    }
}
