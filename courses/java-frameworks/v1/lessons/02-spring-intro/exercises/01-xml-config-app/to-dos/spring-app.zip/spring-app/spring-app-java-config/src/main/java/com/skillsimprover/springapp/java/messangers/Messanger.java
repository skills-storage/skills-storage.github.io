package com.skillsimprover.springapp.java.messangers;

public interface Messanger {

	String getMessage();
}
