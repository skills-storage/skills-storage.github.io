package com.skillsimprover.springapp.bpp.messangers.impl;

import org.springframework.stereotype.Component;

import com.skillsimprover.springapp.bpp.annotations.LocalizedMessage;
import com.skillsimprover.springapp.bpp.messangers.Messanger;

@Component
public class GreetingMessanger implements Messanger {

	@LocalizedMessage(messageCode = "hello.message.code", locale = "it_IT")
	private String message;

	public GreetingMessanger() {
		super();
	}

	@Override
	public String getMessage() {
		return message;
	}
}
