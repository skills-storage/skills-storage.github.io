package com.skillsimprover.springapp.annotations.messangers.impl;

import java.text.DateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.skillsimprover.springapp.annotations.messangers.Messanger;

@Repository
public class GreetingDateMessanger implements Messanger {

	private String message;

	private DateFormat dateFormatter;

	@Autowired
	public GreetingDateMessanger(String message, DateFormat dateFormatter) {
		super();
		this.message = message;
		this.dateFormatter = dateFormatter;
	}

	@Override
	public String getMessage() {
		Date today = getToday();
		String todayStr = dateFormatter.format(today);

		return message + " printed at: " + todayStr;
	}

	private Date getToday() {
		return new Date();
	}
}
