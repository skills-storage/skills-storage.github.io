package com.skillsimprover.springapp.xml.messangers.impl;

import java.text.DateFormat;
import java.util.Date;

import com.skillsimprover.springapp.xml.messangers.Messanger;

public class GreetingDateMessanger implements Messanger {

	private String message;

	private DateFormat dateFormatter;

	public GreetingDateMessanger(String message, DateFormat dateFormatter) {
		super();
		this.message = message;
		this.dateFormatter = dateFormatter;
	}

	@Override
	public String getMessage() {
		Date today = getToday();
		String todayStr = dateFormatter.format(today);

		return message + " printed at: " + todayStr;
	}

	private Date getToday() {
		return new Date();
	}
}
