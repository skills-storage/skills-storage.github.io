package com.skillsimprover.springapp.annotations.formatters.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.skillsimprover.springapp.annotations.formatters.Formatter;
import com.skillsimprover.springapp.annotations.messangers.Messanger;

@Component
public class DollarFormatter implements Formatter {

	private Messanger messanger;

	@Autowired
	public DollarFormatter(@Qualifier("greetingDateMessanger") Messanger messanger) {
		super();
		this.messanger = messanger;
	}

	@Override
	public String formatMessage() {
		StringBuilder builder = new StringBuilder();

		builder.append("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		builder.append("\n");
		builder.append("\t\t\t");
		builder.append(messanger.getMessage());
		builder.append("\n");
		builder.append("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");

		return builder.toString();
	}
}





