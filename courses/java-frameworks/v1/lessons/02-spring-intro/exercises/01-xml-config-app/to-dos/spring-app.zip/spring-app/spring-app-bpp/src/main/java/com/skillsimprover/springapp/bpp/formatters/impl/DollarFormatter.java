package com.skillsimprover.springapp.bpp.formatters.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.skillsimprover.springapp.bpp.annotations.Profiler;
import com.skillsimprover.springapp.bpp.formatters.Formatter;
import com.skillsimprover.springapp.bpp.messangers.Messanger;

@Component("dollarFormatter")
@Profiler
public class DollarFormatter implements Formatter {

	@Autowired
	private Messanger messanger;

	public void setMessanger(Messanger messanger) {
		this.messanger = messanger;
	}

	@Override
	public String formatMessage() {
		StringBuilder builder = new StringBuilder();

		builder.append("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		builder.append("\n");
		builder.append("\t\t\t");
		builder.append(messanger.getMessage());
		builder.append("\n");
		builder.append("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");

		System.out.println("Inside Format Message!");
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return builder.toString();
	}
}





