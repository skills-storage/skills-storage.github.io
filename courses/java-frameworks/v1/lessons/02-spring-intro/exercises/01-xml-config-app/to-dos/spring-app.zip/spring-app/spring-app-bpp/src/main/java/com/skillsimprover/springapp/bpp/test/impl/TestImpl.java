package com.skillsimprover.springapp.bpp.test.impl;

import com.skillsimprover.springapp.bpp.test.Test;

public class TestImpl implements Test {

	public TestImpl() {
		System.out.println("TestImpl - Constructor");
	}

	public void init() {
		System.out.println("TestImpl - Init Method");
	}

	public void destroy() {
		System.out.println("TestImpl - Destroy Method");
	}

	@Override
	protected void finalize() throws Throwable {
		System.out.println("TestImpl - Finalize Method");
	}

	@Override
	public void test() {
		System.out.println("TestImpl - Test Method");
	}
}
