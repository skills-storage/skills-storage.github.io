package com.skillsimprover.springapp.annotations;

import com.skillsimprover.springapp.annotations.di.AppContext;
import com.skillsimprover.springapp.annotations.formatters.Formatter;

public class GreetingApp {

    public static void main( String[] args ) {

    	AppContext appContext = AppContext.getContext();

    	Formatter formatter = appContext.getBean("dollarFormatter");

    	System.out.println(formatter.formatMessage());

    	appContext.destroy();
    }
}
