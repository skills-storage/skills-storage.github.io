package com.skillsimprover.springapp.bpp.processors;

import java.lang.reflect.Field;
import java.util.Locale;
import java.util.ResourceBundle;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.skillsimprover.springapp.bpp.annotations.LocalizedMessage;

public class LocalizedMessageProcessor implements BeanPostProcessor {

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		Class<?> beanClass = bean.getClass();
		Field[] fields = beanClass.getDeclaredFields();

		for (Field field : fields) {
			if (field.isAnnotationPresent(LocalizedMessage.class)) {
				LocalizedMessage localizedMessage = field.getAnnotation(LocalizedMessage.class);

				ResourceBundle bundle = ResourceBundle.getBundle(localizedMessage.bundleName(), new Locale(localizedMessage.locale()));
				String message = bundle.getString(localizedMessage.messageCode());

				try {
					field.setAccessible(true);
					field.set(bean, message);
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			}
		}

		return bean;
	}
}
