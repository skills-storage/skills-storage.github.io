package com.skillsimprover.controltypes.lookup.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.skillsimprover.controltypes.lookup.entities.User;

@WebServlet("/index.html")
public class IndexController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private static final String SELECT_ALL_SQL = "SELECT id, user_name, password FROM users";

	private DataSource dataSource;

	@Override
	public void init() throws ServletException {
		dataSource = initDataSource();
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		List<User> allUsers = loadAllUsers();
		HttpSession session = request.getSession();
		session.setAttribute("all_users_attr", allUsers);

		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/pages/userList.jsp");
		dispatcher.forward(request, response);
	}

	private List<User> loadAllUsers() {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;

		List<User> allUsers = new ArrayList<>();

		try {
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(SELECT_ALL_SQL);
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				Integer id = resultSet.getInt("id");
				String name = resultSet.getString("user_name");
				String password = resultSet.getString("password");

				User user = new User();
				user.setId(id);
				user.setUserName(name);
				user.setPassword(password);

				allUsers.add(user);
			}

			return allUsers;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
				}
			}

			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
				}
			}

			if (resultSet != null) {
				try {
					resultSet.close();
				} catch (SQLException e) {
				}
			}
		}
	}

	private DataSource initDataSource() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}

		try {
			Context initContext = new InitialContext();
			Context rootContext = (Context) initContext.lookup("java:comp/env");
			return (DataSource) rootContext.lookup("jdbc/users_db");
		} catch (NamingException e) {
			throw new RuntimeException("Some errors occurred during DataSource lookup!", e);
		}
	}
}
