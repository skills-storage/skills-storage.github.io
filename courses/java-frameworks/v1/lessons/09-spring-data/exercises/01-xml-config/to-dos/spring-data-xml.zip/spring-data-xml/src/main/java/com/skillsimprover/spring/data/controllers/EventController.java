package com.skillsimprover.spring.data.controllers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.skillsimprover.spring.data.beans.EventBean;
import com.skillsimprover.spring.data.service.EventService;

@Controller
public class EventController {

	@Autowired
	private EventService eventService;

	@RequestMapping("/events.html")
	public ModelAndView showEventsPage() {
		ModelAndView modelAndView = new ModelAndView("events");
		return modelAndView;
	}

	@RequestMapping("/update-event.html")
	public ModelAndView updateEvent(@RequestParam(name = "event_id") Integer eventId) {
		ModelAndView modelAndView = new ModelAndView("events");

		EventBean event = eventService.getEventById(eventId);
		modelAndView.addObject("event", event);

		return modelAndView;
	}

	@RequestMapping("/delete-event.html")
	public ModelAndView deleteEvent(@RequestParam(name = "event_id") Integer eventId) {
		eventService.deleteEvent(eventId);

		ModelAndView modelAndView = new ModelAndView("redirect:events.html");
		return modelAndView;
	}

	@RequestMapping(value = "/save-event.html", method = RequestMethod.POST)
	public ModelAndView saveEvent(EventBean event) {
		eventService.saveEvent(event);

		ModelAndView modelAndView = new ModelAndView("redirect:events.html");
		return modelAndView;
	}

	@ModelAttribute(name = "eventList")
	private Iterable<EventBean> getEventList() {
		Iterable<EventBean> eventList = eventService.getAllEvents();
		return eventList;
	}

	@ModelAttribute(name = "event")
	private EventBean getEmptyEvent() {
		return new EventBean();
	}

	@InitBinder
	public void initBinder(WebDataBinder webDataBinder) {
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		dateFormat.setLenient(false);
		webDataBinder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
}
