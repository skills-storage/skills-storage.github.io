package com.skillsimprover.spring.data.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.spring.data.entities.User;

@Repository
@Transactional
public interface UserDAO extends JpaRepository<User, Integer> {

	@Query("SELECT u FROM User u WHERE LOWER(u.userName) = LOWER(:userName)")
	User loadUserByUsername(String userName);
}
