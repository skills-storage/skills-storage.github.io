package com.skillsimprover.spring.data.service;

import com.skillsimprover.spring.data.beans.EventBean;

public interface EventService {

	Iterable<EventBean> getAllEvents();

	EventBean getEventById(Integer eventId);

	void saveEvent(EventBean event);

	void deleteEvent(Integer eventId);
}
