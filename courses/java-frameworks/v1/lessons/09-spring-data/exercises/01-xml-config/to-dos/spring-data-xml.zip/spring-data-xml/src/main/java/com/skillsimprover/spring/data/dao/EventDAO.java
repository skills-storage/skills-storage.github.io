package com.skillsimprover.spring.data.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.spring.data.entities.Event;

@Repository
@Transactional
public interface EventDAO extends JpaRepository<Event, Integer> {
}
