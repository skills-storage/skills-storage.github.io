package com.skillsimprover.spring.data.dao;

import org.springframework.data.repository.CrudRepository;

import com.skillsimprover.spring.data.entities.Event;

public interface EventDAO extends CrudRepository<Event, Integer> {
}
