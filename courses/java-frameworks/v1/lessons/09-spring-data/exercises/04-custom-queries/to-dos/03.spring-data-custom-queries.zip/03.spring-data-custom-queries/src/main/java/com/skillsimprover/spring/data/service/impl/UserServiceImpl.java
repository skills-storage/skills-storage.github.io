package com.skillsimprover.spring.data.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.spring.data.beans.UserBean;
import com.skillsimprover.spring.data.dao.UserDAO;
import com.skillsimprover.spring.data.entities.User;
import com.skillsimprover.spring.data.service.EntityBeanConverter;
import com.skillsimprover.spring.data.service.UserService;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDao;

	@Autowired
	private EntityBeanConverter converter;

	@Override
	public Iterable<UserBean> getAllUsers() {
		Iterable<User> users = userDao.findAll();
		List<UserBean> beanList = converter.convertToBeanList(users, UserBean.class);

		return beanList;
	}

	@Override
	public UserBean getUserById(Integer userId) {
		User user = userDao.findOne(userId);
		UserBean bean = converter.convertToBean(user, UserBean.class);

		return bean;
	}

	@Override
	public void saveUser(UserBean user) {
		User userEntity = converter.convertToEntity(user, User.class);
		userDao.save(userEntity);
	}

	@Override
	public void deleteUser(Integer userId) {
		userDao.delete(userId);
	}
}
