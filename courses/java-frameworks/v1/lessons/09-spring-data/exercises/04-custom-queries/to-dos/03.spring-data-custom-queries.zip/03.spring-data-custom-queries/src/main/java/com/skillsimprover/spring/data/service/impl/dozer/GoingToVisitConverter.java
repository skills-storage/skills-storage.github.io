package com.skillsimprover.spring.data.service.impl.dozer;

import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerConverter;

import com.skillsimprover.spring.data.beans.VisitEventBean;
import com.skillsimprover.spring.data.entities.Event;

@SuppressWarnings("rawtypes")
public class GoingToVisitConverter extends DozerConverter<List, List> {

	public GoingToVisitConverter() {
		super(List.class, List.class);
	}

	@Override
	public List convertTo(List source, List destination) {
		return new ArrayList<>();
	}

	@Override
	public List convertFrom(List source, List destination) {
		List<VisitEventBean> result = new ArrayList<>();

		for (Object object : source) {
			Event event = (Event) object;
			VisitEventBean bean = new VisitEventBean();

			bean.setId(event.getId());
			bean.setEventName(event.getName());
			bean.setEventDate(event.getDate());

			result.add(bean);
		}

		return result;
	}
}
