package com.skillsimprover.spring.data.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.spring.data.beans.EventBean;
import com.skillsimprover.spring.data.dao.EventDAO;
import com.skillsimprover.spring.data.entities.Event;
import com.skillsimprover.spring.data.service.EntityBeanConverter;
import com.skillsimprover.spring.data.service.EventService;

@Service
@Transactional
public class EventServiceImpl implements EventService {

	@Autowired
	private EventDAO eventDao;

	@Autowired
	private EntityBeanConverter converter;

	@Override
	public Iterable<EventBean> getAllEvents() {
		Iterable<Event> events = eventDao.findAll();
		List<EventBean> beanList = converter.convertToBeanList(events, EventBean.class);

		return beanList;
	}

	@Override
	public EventBean getEventById(Integer eventId) {
		Event event = eventDao.findOne(eventId);
		EventBean bean = converter.convertToBean(event, EventBean.class);

		return bean;
	}

	@Override
	public void saveEvent(EventBean event) {
		Event eventEntity = converter.convertToEntity(event, Event.class);
		eventDao.save(eventEntity);
	}

	@Override
	public void deleteEvent(Integer eventId) {
		eventDao.delete(eventId);
	}
}
