DROP SCHEMA IF EXISTS `events_db`;

CREATE SCHEMA IF NOT EXISTS `events_db`;

USE `events_db`;

-- ******************** Table Definitions ******************** 
CREATE TABLE `users` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `user_name` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL
);

CREATE TABLE `events` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `event_name` VARCHAR(255) NOT NULL,
  `event_desc` TEXT NOT NULL,
  `event_date` DATE NOT NULL
);

-- ************************ Test Data for table users ************************ 
INSERT INTO `users` (`user_name`, `password`) VALUES ('ivan', 'ivan_123');
INSERT INTO `users` (`user_name`, `password`) VALUES ('petr', 'petr_123');
INSERT INTO `users` (`user_name`, `password`) VALUES ('sidor', 'sidor_123');

-- ************************ Test Data for table events ************************ 
INSERT INTO `events` (`event_name`, `event_desc`, `event_date`) VALUES ('Java One', 'Very good conference for Java developers', '2017-01-17');
INSERT INTO `events` (`event_name`, `event_desc`, `event_date`) VALUES ('C++ conference', 'Very good conference for C\C++ developers', '2017-01-27');
INSERT INTO `events` (`event_name`, `event_desc`, `event_date`) VALUES ('PHP conference', 'Very good conference for PHP developers', '2017-01-30');
