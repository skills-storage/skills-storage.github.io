package com.skillsimprover.lombok.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.lombok.beans.UserBean;
import com.skillsimprover.lombok.dao.UserDAO;
import com.skillsimprover.lombok.entities.User;
import com.skillsimprover.lombok.service.EntityBeanConverter;
import com.skillsimprover.lombok.service.UserService;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDao;

	@Autowired
	private EntityBeanConverter converter;

	@Override
	public Iterable<UserBean> getAllUsers() {
		List<User> users = userDao.findAll();
		List<UserBean> userBeans = converter.convertToBeanList(users, UserBean.class);

		return userBeans;
	}

	@Override
	public UserBean getUserById(Integer userId) {
		User user = userDao.getOne(userId);
		UserBean userBean = converter.convertToBean(user, UserBean.class);

		return userBean;
	}

	@Override
	public void saveUser(UserBean user) {
		User userEntity = converter.convertToEntity(user, User.class);
		userDao.save(userEntity);
	}

	@Override
	public void deleteUser(Integer userId) {
		userDao.deleteById(userId);
	}
}
