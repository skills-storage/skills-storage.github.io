package com.skillsimprover.lombok.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.lombok.beans.EventBean;
import com.skillsimprover.lombok.dao.EventDAO;
import com.skillsimprover.lombok.entities.Event;
import com.skillsimprover.lombok.service.EntityBeanConverter;
import com.skillsimprover.lombok.service.EventService;

@Service
@Transactional
public class EventServiceImpl implements EventService {

	@Autowired
	private EventDAO eventDao;

	@Autowired
	private EntityBeanConverter converter;

	@Override
	public Iterable<EventBean> getAllEvents() {
		List<Event> events = eventDao.findAll();
		List<EventBean> eventBeans = converter.convertToBeanList(events, EventBean.class);

		return eventBeans;
	}

	@Override
	public EventBean getEventById(Integer eventId) {
		Event event = eventDao.getOne(eventId);
		EventBean eventBean = converter.convertToBean(event, EventBean.class);

		return eventBean;
	}

	@Override
	public void saveEvent(EventBean event) {
		Event eventEntity = converter.convertToEntity(event, Event.class);
		eventDao.save(eventEntity);
	}

	@Override
	public void deleteEvent(Integer eventId) {
		eventDao.deleteById(eventId);
	}
}
