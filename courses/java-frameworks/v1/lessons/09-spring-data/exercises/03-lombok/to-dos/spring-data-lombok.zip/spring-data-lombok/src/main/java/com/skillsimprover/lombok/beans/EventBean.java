package com.skillsimprover.lombok.beans;

import java.util.Date;

import lombok.Data;

@Data
@SuppressWarnings("unused")
public class EventBean {

	private Integer id;

	private String name;

	private String description;

	private Date date;
}
