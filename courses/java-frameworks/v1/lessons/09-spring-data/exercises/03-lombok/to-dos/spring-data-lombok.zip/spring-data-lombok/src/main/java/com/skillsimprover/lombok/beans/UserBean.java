package com.skillsimprover.lombok.beans;

import lombok.Data;

@Data
@SuppressWarnings("unused")
public class UserBean {

	private Integer id;

	private String userName;

	private String password;
}
