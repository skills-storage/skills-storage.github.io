package com.skillsimprover.lombok.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.lombok.entities.Event;

@Repository
@Transactional
public interface EventDAO extends JpaRepository<Event, Integer> {
}
