package com.skillsimprover.lombok.service;

import com.skillsimprover.lombok.beans.EventBean;

public interface EventService {

	Iterable<EventBean> getAllEvents();

	EventBean getEventById(Integer eventId);

	void saveEvent(EventBean event);

	void deleteEvent(Integer eventId);
}
