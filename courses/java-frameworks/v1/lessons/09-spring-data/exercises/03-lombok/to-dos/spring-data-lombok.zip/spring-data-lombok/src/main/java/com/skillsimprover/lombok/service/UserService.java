package com.skillsimprover.lombok.service;

import com.skillsimprover.lombok.beans.UserBean;

public interface UserService {

	Iterable<UserBean> getAllUsers();

	UserBean getUserById(Integer userId);

	void saveUser(UserBean user);

	void deleteUser(Integer userId);
}
