package com.skillsimprover.spring.data.service;

import com.skillsimprover.spring.data.beans.UserBean;

public interface UserService {

	Iterable<UserBean> getAllUsers();

	UserBean getUserById(Integer userId);

	void saveUser(UserBean user);

	void deleteUser(Integer userId);
}
