package com.skillsimprover.spring.data.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillsimprover.spring.data.beans.EventBean;
import com.skillsimprover.spring.data.dao.EventDAO;
import com.skillsimprover.spring.data.entities.Event;
import com.skillsimprover.spring.data.service.EntityBeanConverter;
import com.skillsimprover.spring.data.service.EventService;

@Service
@Transactional
public class EventServiceImpl implements EventService {

	@Autowired
	private EventDAO eventDao;

	@Autowired
	private EntityBeanConverter converter;

	@Override
	public Iterable<EventBean> getAllEvents() {
		List<Event> events = eventDao.findAll();
		List<EventBean> eventBeans = converter.convertToBeanList(events, EventBean.class);

		return eventBeans;
	}

	@Override
	public EventBean getEventById(Integer eventId) {
		Event event = eventDao.getOne(eventId);
		EventBean eventBean = converter.convertToBean(event, EventBean.class);

		return eventBean;
	}

	@Override
	public void saveEvent(EventBean event) {
		Event eventEntity = converter.convertToEntity(event, Event.class);
		eventDao.save(eventEntity);
	}

	@Override
	public void deleteEvent(Integer eventId) {
		eventDao.deleteById(eventId);
	}
}
