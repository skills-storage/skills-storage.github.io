package com.skillsimprover.springmvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class TrainingsController {

	@GetMapping("/trainings")
	public String showTrainingListPage() {
		return "trainings/trainings-list";
	}

	@GetMapping("/add-training")
	public String addNewTraining() {
		return "trainings/training-details";
	}

	@GetMapping("/edit-training")
	public String editTraining() {
		return "trainings/training-details";
	}

	@GetMapping("/delete-training")
	public String deleteUser() {
		return "redirect:/trainings";
	}

	@PostMapping("/save-training")
	public String saveUser() {
		return "redirect:/trainings";
	}
}
