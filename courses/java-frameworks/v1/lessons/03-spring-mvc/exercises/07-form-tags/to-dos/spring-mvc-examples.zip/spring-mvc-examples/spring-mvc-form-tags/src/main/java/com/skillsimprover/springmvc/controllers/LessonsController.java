package com.skillsimprover.springmvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LessonsController {

	@GetMapping("/lessons")
	public String showLessonListPage() {
		return "lessons/lessons-list";
	}

	@GetMapping("/add-lesson")
	public String addNewLesson() {
		return "lessons/lesson-details";
	}

	@GetMapping("/edit-lesson")
	public String editLesson() {
		return "lessons/lesson-details";
	}

	@GetMapping("/delete-lesson")
	public String deleteLesson() {
		return "redirect:/lessons";
	}

	@PostMapping("/save-lesson")
	public String saveLesson() {
		return "redirect:/lessons";
	}
}
