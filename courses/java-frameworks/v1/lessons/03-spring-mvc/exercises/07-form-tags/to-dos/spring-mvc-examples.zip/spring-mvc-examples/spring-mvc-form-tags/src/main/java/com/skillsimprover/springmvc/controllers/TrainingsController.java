package com.skillsimprover.springmvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.skillsimprover.springmvc.dto.Training;

@Controller
public class TrainingsController {

	@GetMapping("/trainings")
	public String showTrainingListPage() {
		return "trainings/trainings-list";
	}

	@GetMapping("/add-training")
	public String addNewTraining() {
		return "trainings/training-details";
	}

	@GetMapping("/edit-training")
	public String editTraining() {
		return "trainings/training-details";
	}

	@GetMapping("/delete-training")
	public String deleteUser() {
		return "redirect:/trainings";
	}

	@PostMapping("/save-training")
	public String saveUser(@ModelAttribute("training") Training training) {
		return "redirect:/trainings";
	}

	@ModelAttribute("training")
	private Training getEmptyTrainig() {
		return new Training();
	}
}
