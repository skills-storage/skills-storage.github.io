package com.skillsimprover.springmvc.dto;

public class Training {

    private String trainingName;

    private Integer lessonsCount;

	public Training() {
		super();
	}

	public String getTrainingName() {
		return trainingName;
	}

	public void setTrainingName(String trainingName) {
		this.trainingName = trainingName;
	}

	public Integer getLessonsCount() {
		return lessonsCount;
	}

	public void setLessonsCount(Integer lessonsCount) {
		this.lessonsCount = lessonsCount;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((trainingName == null) ? 0 : trainingName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Training other = (Training) obj;
		if (trainingName == null) {
			if (other.trainingName != null) {
				return false;
			}
		} else if (!trainingName.equals(other.trainingName)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Training [trainingName=");
		builder.append(trainingName);
		builder.append(", lessonsCount=");
		builder.append(lessonsCount);
		builder.append("]");
		return builder.toString();
	}
}
