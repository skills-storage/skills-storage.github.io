package com.skillsimprover.spring.resources.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.skillsimprover.spring.resources.beans.User;

@Controller
public class LoginController {

	@RequestMapping("/login.html")
	public ModelAndView showLoginPage() {
		ModelAndView modelAndView = new ModelAndView("login.page", "user", new User());
		return modelAndView;
	}
}
