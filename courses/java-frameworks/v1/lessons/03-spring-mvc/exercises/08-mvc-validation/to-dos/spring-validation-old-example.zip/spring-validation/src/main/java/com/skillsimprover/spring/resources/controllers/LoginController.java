package com.skillsimprover.spring.resources.controllers;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.skillsimprover.spring.resources.beans.User;

@Controller
public class LoginController {

	@RequestMapping("/login.html")
	public ModelAndView showLoginPage() {
		ModelAndView modelAndView = new ModelAndView("login.page", "user", new User());
		return modelAndView;
	}

	@RequestMapping(value = "/authorize.html", method=RequestMethod.POST)
	public ModelAndView authorize(@ModelAttribute("user") @Valid User user, BindingResult result) {
		if (result.hasErrors()) {
			return new ModelAndView("login.page", "user", user);
		}

		return new ModelAndView("redirect:/profile.html");
	}
}
