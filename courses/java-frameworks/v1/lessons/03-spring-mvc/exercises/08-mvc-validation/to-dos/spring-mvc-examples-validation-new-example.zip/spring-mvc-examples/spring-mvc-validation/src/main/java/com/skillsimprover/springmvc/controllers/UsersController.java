package com.skillsimprover.springmvc.controllers;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.skillsimprover.springmvc.dto.User;

@Controller
public class UsersController {

	@GetMapping("/users")
	public String showUsersListPage() {
		return "users/users-list";
	}

	@GetMapping("/add-user")
	public String addNewUser() {
		return "users/user-details";
	}

	@GetMapping("/edit-user")
	public String editUser() {
		return "users/user-details";
	}

	@GetMapping("/delete-user")
	public String deleteUser() {
		return "redirect:/users";
	}

	@PostMapping(value = "/save-user", params = "saveUser")
	public String saveUser(@Valid @ModelAttribute User user, BindingResult validation) {
		if (validation.hasErrors()) {
			return "users/user-details";
		}

		// Call service to asve User here

		return "redirect:/users";
	}

	@PostMapping(value = "/save-user", params = "cancelSave")
	public String cancelSaveUser() {
		return "redirect:/users";
	}

	@ModelAttribute("user")
	private User getEmptyUser() {
		return new User();
	}
}
