package com.skillsimprover.springmvc.advices;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class UrlTrackerAdvise {

	public void trackProcessedUrl() {
		System.out.println("trackProcessedUrl");
	}
	
}
