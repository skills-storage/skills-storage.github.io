package com.skillsimprover.spring.mvc.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.skillsimprover.spring.mvc.beans.User;
import com.skillsimprover.spring.mvc.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	private List<User> usersDb = new ArrayList<>();

	public UserServiceImpl() {
		User user1 = new User("Ivan", "Ivanov");
		User user2 = new User("Petr", "Petrov");
		User user3 = new User("Sidor", "Sidorov");

		usersDb.add(user1);
		usersDb.add(user2);
		usersDb.add(user3);
	}

	@Override
	public Iterable<User> getAllUsers() {
		return usersDb;
	}

	@Override
	public User getUserById(Integer userId) {
		for (User user : usersDb) {
			if (user.getId().equals(userId)) {
				return user;
			}
		}

		return null;
	}

	@Override
	public void saveUser(User user) {
		if (user.getId() == null) {
			user.generateId();
			usersDb.add(user);
			return;
		}

		User storedUser = getUserById(user.getId());
		storedUser.setFirstName(user.getFirstName());
		storedUser.setLastName(user.getLastName());
	}

	@Override
	public void deleteUser(Integer userId) {
		User user = getUserById(userId);
		if (user != null) {
			usersDb.remove(user);
		}
	}
}
