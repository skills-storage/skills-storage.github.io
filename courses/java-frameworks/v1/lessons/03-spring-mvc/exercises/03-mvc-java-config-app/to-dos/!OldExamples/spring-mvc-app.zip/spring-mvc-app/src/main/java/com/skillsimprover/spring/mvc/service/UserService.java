package com.skillsimprover.spring.mvc.service;

import com.skillsimprover.spring.mvc.beans.User;

public interface UserService {

	Iterable<User> getAllUsers();

	User getUserById(Integer userId);

	void saveUser(User user);

	void deleteUser(Integer userId);
}
