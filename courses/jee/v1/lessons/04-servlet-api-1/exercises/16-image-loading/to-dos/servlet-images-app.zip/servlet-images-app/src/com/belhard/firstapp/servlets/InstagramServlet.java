package com.belhard.firstapp.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/instagram")
public class InstagramServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("Welcome to our instagrammmm!");
        out.println("<br>");


        String imageDb = "h:/data-storadge";
        File file = new File(imageDb);
        File[] images = file.listFiles();

        for (File image : images) {
            String imageName = image.getName();
            out.println("<br>");
            out.println("<img height='200px' width='200px' src='get-image?imageName=" + imageName + "'>");

            out.println("<br>");
            out.println("<br>");
        }
    }
}
