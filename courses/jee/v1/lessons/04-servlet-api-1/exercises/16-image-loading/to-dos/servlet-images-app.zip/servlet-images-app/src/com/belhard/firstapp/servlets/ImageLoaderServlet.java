package com.belhard.firstapp.servlets;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@WebServlet("/get-image")
public class ImageLoaderServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String imageName = req.getParameter("imageName");
        if (imageName != null) {
            ServletOutputStream out = resp.getOutputStream();
            out.write(getImage(imageName));
        }
    }

    private byte[] getImage(String imageName) throws IOException {
        String imageDb = "h:/data-storadge";
        File file = new File(imageDb);
        File[] images = file.listFiles();

        for (File image : images) {
            if (image.getName().equals(imageName)) {
                return Files.readAllBytes(Paths.get(image.getAbsolutePath()));
            }
        }

        throw new IOException("No Image");

    }
}
