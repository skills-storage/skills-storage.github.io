package com.skillsimprover.jdbc.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class ConnectionManager {

	private ConnectionManager() {
		throw new InstantiationError("No need to create instances for static content!");
	}

	public static Connection getConnection() {
		try {
			Context initContext = new InitialContext();
			Context rootContext = (Context) initContext.lookup("java:comp/env");
			DataSource dataSource = (DataSource) rootContext.lookup("jdbc/personnel_department_db_link");

			Connection connection = dataSource.getConnection();

			return connection;
		} catch (SQLException e) {
			throw new RuntimeException("Some errors occurred during DB access!", e);
		} catch (NamingException e) {
			throw new RuntimeException("Some errors occurred during DataSource lookup!", e);
		}
	}
	
	public static void closeDbResources(Connection connection, Statement statement) {
		closeDbResources(connection, statement, null);
	}

	public static void closeDbResources(Connection connection, Statement statement, ResultSet resultSet) {
		closeResultSet(resultSet);
		closeStatement(statement);
		closeConnection(connection);
	}

	private static void closeConnection(Connection connection) {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Error: Connection has not been closed!");
			}
		}
	}

	private static void closeStatement(Statement statement) {
		if (statement != null) {
			try {
				statement.close();
			} catch (SQLException e) {
				System.out.println("Error: Statement has not been closed!");
			}
		}
	}

	private static void closeResultSet(ResultSet resultSet) {
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (SQLException e) {
				System.out.println("Error: ResultSet has not been closed!");
			}
		}
	}
}
