CREATE TABLE `groups` (
  `id` INTEGER NOT NULL AUTO_INCREMENT,
  `group_name` VARCHAR(255) NOT NULL,
  `start_traning_date` DATETIME NOT NULL,
  `fk_course_id` INTEGER NOT NULL,

  PRIMARY KEY  (`id`),

  CONSTRAINT `fk_group_to_course` FOREIGN KEY (`fk_course_id`) REFERENCES `courses` (`id`)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT
);

CREATE TABLE `profiles_to_groups` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `fk_profile_id` INTEGER NOT NULL,
  `fk_group_id` INTEGER NOT NULL,

  CONSTRAINT `fk_to_profile` FOREIGN KEY (`fk_profile_id`) REFERENCES `profiles` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,

  CONSTRAINT `fk_to_group` FOREIGN KEY (`fk_group_id`) REFERENCES `groups` (`id`)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT
);
