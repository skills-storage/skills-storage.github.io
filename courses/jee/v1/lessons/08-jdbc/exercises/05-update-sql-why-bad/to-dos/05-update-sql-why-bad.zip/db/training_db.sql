DROP SCHEMA IF EXISTS `personnel_department_db`;

CREATE SCHEMA IF NOT EXISTS `personnel_department_db`
CHARACTER SET `utf8`;

USE `personnel_department_db`;

CREATE TABLE `employees` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `email` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `salary` NUMERIC(10, 2) NOT NULL
);

INSERT INTO `personnel_department_db`.`employees` (`id`, `email`, `password`, `salary`) VALUES (1, 'ivan@gmail.com', 'secret', 12.50);
INSERT INTO `personnel_department_db`.`employees` (`id`, `email`, `password`, `salary`) VALUES (2, 'petr@gmail.com', 'qwert', 55.99);
INSERT INTO `personnel_department_db`.`employees` (`id`, `email`, `password`, `salary`) VALUES (3, 'sidor@gmail.com', 'SuperstR0NGpassWord', 1000.20);
