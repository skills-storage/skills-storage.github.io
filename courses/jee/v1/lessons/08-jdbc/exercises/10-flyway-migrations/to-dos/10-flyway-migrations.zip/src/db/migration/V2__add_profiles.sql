CREATE TABLE `profiles` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `first_name` VARCHAR(255) NOT NULL,
  `last_name` VARCHAR(255) NOT NULL,
  `middle_name` VARCHAR(255) DEFAULT NULL
);

INSERT INTO `profiles` (`id`, `first_name`, `last_name`, `middle_name`) VALUES (1, 'Михаил', 'Лазаревич', null);

ALTER TABLE `accounts`
	ADD CONSTRAINT `fk_account_to_profile` FOREIGN KEY (`id`) REFERENCES `profiles` (`id`)
		ON DELETE CASCADE
		ON UPDATE CASCADE;

ALTER TABLE `profiles`
	ADD CONSTRAINT `fk_profile_to_account` FOREIGN KEY (`id`) REFERENCES `accounts` (`id`)
		ON DELETE CASCADE
		ON UPDATE CASCADE;
