DROP SCHEMA IF EXISTS `training_db`;

CREATE SCHEMA IF NOT EXISTS `training_db`
CHARACTER SET `utf8`;

USE `training_db`;
