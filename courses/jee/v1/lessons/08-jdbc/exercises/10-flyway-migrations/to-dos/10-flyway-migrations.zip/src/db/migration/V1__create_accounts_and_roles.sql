CREATE TABLE `roles` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `role_name` VARCHAR(255) NOT NULL
);

CREATE TABLE `accounts` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `email` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL
);

CREATE TABLE `accounts_to_roles` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `fk_role_id` INTEGER NOT NULL,
  `fk_account_id` INTEGER NOT NULL,

  CONSTRAINT `fk_to_role` FOREIGN KEY (`fk_role_id`) REFERENCES `roles` (`id`)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT,

  CONSTRAINT `fk_to_account` FOREIGN KEY (`fk_account_id`) REFERENCES `accounts` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

INSERT INTO `roles` (`id`, `role_name`) VALUES (1, 'Administrator');
INSERT INTO `roles` (`id`, `role_name`) VALUES (2, 'Prepod');
INSERT INTO `roles` (`id`, `role_name`) VALUES (3, 'Student');

INSERT INTO `accounts` (`id`, `email`, `password`) VALUES (1, 'admin@gmail.com', 'super_secret');

INSERT INTO `accounts_to_roles` (`fk_role_id`, `fk_account_id`) VALUES (1, 1);
INSERT INTO `accounts_to_roles` (`fk_role_id`, `fk_account_id`) VALUES (2, 1);
