CREATE TABLE `categories` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `category_name` VARCHAR(255) NOT NULL
);

CREATE TABLE `courses` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `course_name` VARCHAR(555) NOT NULL,
  `fk_category_id` INTEGER default NULL,
  `fk_profile_id` INTEGER NOT NULL,

  CONSTRAINT `fk_course_to_category` FOREIGN KEY (`fk_category_id`) REFERENCES `categories` (`id`)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT,

  CONSTRAINT `fk_course_to_profile` FOREIGN KEY (`fk_profile_id`) REFERENCES `profiles` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

CREATE TABLE `lessons` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `lesson_name` VARCHAR(755) NOT NULL,
  `lesson_order` INTEGER NOT NULL,
  `fk_course_id` INTEGER default NULL,

  CONSTRAINT `fk_lesson_to_course` FOREIGN KEY (`fk_course_id`) REFERENCES `courses` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

INSERT INTO `categories` (`id`, `category_name`) VALUES (1, 'Программирование');
INSERT INTO `categories` (`id`, `category_name`) VALUES (2, 'Выживание');
INSERT INTO `categories` (`id`, `category_name`) VALUES (3, 'Рукоделие');

INSERT INTO `courses` (`id`, `course_name`, `fk_category_id`, `fk_profile_id`) VALUES (1, 'Java Enterprise Edition', 1, 1);
INSERT INTO `courses` (`id`, `course_name`, `fk_category_id`, `fk_profile_id`) VALUES (2, 'Езда в троллейбусе в час пик', 2, 1);

INSERT INTO `lessons` (`lesson_name`, `lesson_order`, `fk_course_id`) VALUES ('Web Development - HTML, CSS, JS', 1, 1);
INSERT INTO `lessons` (`lesson_name`, `lesson_order`, `fk_course_id`) VALUES ('Web Development on Java Platform', 2, 1);
INSERT INTO `lessons` (`lesson_name`, `lesson_order`, `fk_course_id`) VALUES ('Servlets API', 3, 1);
INSERT INTO `lessons` (`lesson_name`, `lesson_order`, `fk_course_id`) VALUES ('JSP - Java Server Pages', 4, 1);
