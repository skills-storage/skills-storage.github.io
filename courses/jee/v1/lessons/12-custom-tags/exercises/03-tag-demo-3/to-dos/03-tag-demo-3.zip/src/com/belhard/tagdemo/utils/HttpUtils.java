package com.belhard.tagdemo.utils;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public final class HttpUtils {

	public HttpUtils() {
		super();
	}

	public static String getStringParameter(HttpServletRequest request, String paramName) {
		if (StringUtils.isBlank(paramName)) {
			throw new IllegalArgumentException();
		}

		String value = request.getParameter(paramName);
		if (value != null) {
			return value;
		}

		return StringUtils.EMPTY_STR;
	}

	public static Integer getIntParameter(HttpServletRequest request, String paramName) {
		String value = getStringParameter(request, paramName);
		try {
			return new Integer(value);
		} catch (Exception e) {
			return null;
		}
	}

	public static List<?> getListAttribute(HttpSession session, String attrName) {
		if (StringUtils.isBlank(attrName)) {
			throw new IllegalArgumentException();
		}

		Object value = session.getAttribute(attrName);
		if (value == null) {
			return new ArrayList<Object>();
		}

		if (!(value instanceof List<?>)) {
			throw new IllegalArgumentException();
		}

		List<?> list = (List<?>) value;
		return list;
	}
}
