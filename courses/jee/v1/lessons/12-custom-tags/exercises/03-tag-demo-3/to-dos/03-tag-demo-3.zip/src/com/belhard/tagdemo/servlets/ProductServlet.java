package com.belhard.tagdemo.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.belhard.tagdemo.beans.ProductBean;
import com.belhard.tagdemo.utils.HttpUtils;
import com.belhard.tagdemo.utils.IdGenerator;
import com.belhard.tagdemo.utils.RequestConstants;
import com.belhard.tagdemo.utils.SessionConstants;
import com.belhard.tagdemo.utils.StringUtils;
import com.sun.org.apache.bcel.internal.classfile.Attribute;

public class ProductServlet extends HttpServlet {

	private static final String PRODUCTS_VIEW_PATH = "/WEB-INF/pages/products.jsp";

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		RequestConstants actionType = getRequestParameter(request, RequestConstants.ActionTypeParam);

		switch (actionType) {
			case AddActionParam: {
				addProduct(request);
				break;
			}
			case RemoveActionParam: {
				removeProduct(request);
				break;
			}
		}

		forward(PRODUCTS_VIEW_PATH, request, response);
	}

	private void forward(String address, 
                         HttpServletRequest request, 
                         HttpServletResponse response) throws ServletException, IOException {

		RequestDispatcher dispatcher = request.getRequestDispatcher(address);
		dispatcher.forward(request, response);
	}

	private void addProduct(HttpServletRequest request) {
		HttpSession session = request.getSession();

		List<ProductBean> productBeans = (List<ProductBean>)getListAttribute(session, SessionConstants.ProductListAttr);
		String productName = getStringParameter(request, RequestConstants.ProductNameParam);

		ProductBean bean = new ProductBean();
		bean.setName(productName);

		productBeans.add(bean);

		session.setAttribute(SessionConstants.ProductListAttr.getName(), productBeans);
	}

	private void removeProduct(HttpServletRequest request) {
		HttpSession session = request.getSession();

		List<ProductBean> productBeans = (List<ProductBean>)getListAttribute(session, SessionConstants.ProductListAttr);
		Integer productId = getIntParameter(request, RequestConstants.ProductIdParam);
		if (productId == null) {
			return;
		}

		for (ProductBean bean : productBeans) {
			if (bean.isEqualId(productId)) {
				productBeans.remove(bean);
				return;
			}
		}
	}

	private RequestConstants getRequestParameter(HttpServletRequest request, RequestConstants parameter) {
		String requestParam = getStringParameter(request, parameter);

		try {
			RequestConstants paramConstant = RequestConstants.getConstantByName(requestParam);
			return paramConstant;
		} catch (Exception e) {
			return RequestConstants.UnknownParam;
		}
	}

	private String getStringParameter(HttpServletRequest request, RequestConstants parameter) {
		return HttpUtils.getStringParameter(request, parameter.getName());
	}

	private Integer getIntParameter(HttpServletRequest request, RequestConstants parameter) {
		return HttpUtils.getIntParameter(request, parameter.getName());
	}

	private List<?> getListAttribute(HttpSession session, SessionConstants attribute) {
		return HttpUtils.getListAttribute(session, attribute.getName());
	}
}
