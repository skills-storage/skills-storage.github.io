package com.belhard.tagdemo.utils;

public enum RequestConstants {

	UnknownParam("unknown"),

	ProductNameParam("txt_product_name"),

	ProductIdParam("hdn_removed_product"),

	ActionTypeParam("hdn_action_type"),

	ListActionParam("list_action"),

	AddActionParam("add_action"),

	RemoveActionParam("remove_action");

	private String name;

	private RequestConstants(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public static RequestConstants getConstantByName(String constantName) {
		if (StringUtils.isBlank(constantName)) {
			return RequestConstants.UnknownParam;
		}

		for (RequestConstants constant : RequestConstants.values()) {
			if (constantName.equalsIgnoreCase(constant.name)) {
				return constant;
			}
		}

		return RequestConstants.UnknownParam;
	}
}
