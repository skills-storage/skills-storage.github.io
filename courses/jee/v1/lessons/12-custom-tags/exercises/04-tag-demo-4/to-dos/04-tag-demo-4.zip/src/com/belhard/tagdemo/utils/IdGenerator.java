package com.belhard.tagdemo.utils;

public final class IdGenerator {

	private static int currentId = 0;

	private IdGenerator() {
		super();
	}

	public static int generateNextId() {
		currentId++;
		return currentId;
	}
}
