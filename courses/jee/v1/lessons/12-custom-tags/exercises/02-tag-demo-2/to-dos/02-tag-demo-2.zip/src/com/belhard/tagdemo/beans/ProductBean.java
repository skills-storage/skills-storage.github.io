package com.belhard.tagdemo.beans;

import java.io.Serializable;

import com.belhard.tagdemo.utils.IdGenerator;

public class ProductBean implements Serializable {

	private Integer id;

	private String name;

	public ProductBean() {
		super();
		this.id = IdGenerator.generateNextId();
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isEqualId(Integer anotherId) {
		return id.equals(anotherId);
	}

	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		if (getClass() != obj.getClass()) {
			return false;
		}

		ProductBean other = (ProductBean) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		}

		return (id.equals(other.id));
	}
}
