package com.belhard.tagdemo.tags;

import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import com.belhard.tagdemo.beans.ProductBean;
import com.belhard.tagdemo.utils.HttpUtils;
import com.belhard.tagdemo.utils.StringUtils;

public class ProductsGridTag extends TagSupport {

	private String border;

	@Override
	public int doStartTag() throws JspException {
		JspWriter out = pageContext.getOut();
		
		try {
			out.println("<table");
			
			if (StringUtils.isNotBlank(border)) {
				out.println(" border=\"" + border + "\"");
			}

			out.println(">");
			out.println("<tr>");
			out.println("<th colspan=\"2\">Список товаров</th>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<th width=\"250px\">Название</th>");
			out.println("<th width=\"150px\"></th>");
			out.println("</tr>");

			List<ProductBean> productBeans = (List<ProductBean>)HttpUtils.getListAttribute(pageContext.getSession(), "product_list_attr");
			for(ProductBean product : productBeans) {
				out.println("<tr>");
				out.println("<td>");
				out.println(product.getName());
				out.println("</td>");
				out.println("<td>");
				out.println("<a href=\"#\" onclick=\"submitRemoveAction(" + product.getId() + ")\">Удалить</a>");
				out.println("</td>");
				out.println("</tr>");

			}
		} catch (Exception e) {
			throw new JspException();
		}

		return SKIP_BODY;
	}

	@Override
	public int doEndTag() throws JspException {
		JspWriter out = pageContext.getOut();

		try {
			out.println("</table>");
		} catch (Exception e) {
			throw new JspException();
		}

		return EVAL_PAGE;
	}

	public String getBorder() {
		return border;
	}

	public void setBorder(String border) {
		this.border = border;
	}
}
