package com.belhard.tagdemo.utils;

public enum SessionConstants {

	ProductListAttr("product_list_attr");

	private String name;

	private SessionConstants(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
